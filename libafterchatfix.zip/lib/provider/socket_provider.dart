import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '/utilities/app_constant.dart';

class SocketProvider extends ChangeNotifier with WidgetsBindingObserver {
  final bool _enableLifecycleReconnect;
  IO.Socket? socket;
  String? userId;

  int _currentPage = 1;
  bool _hasMore = true;
  bool _isLoadingMore = false;
  bool get isLoadingMore => _isLoadingMore;

  bool _isConnected = false;
  bool get isConnected => _isConnected;
  DateTime? _lastSocketErrorLogAt;
  Timer? _reconnectTimer;
  final List<Map<String, dynamic>> _pendingConversationMessages = [];

  // List<dynamic> _bookingList = [];
  // List<dynamic> get bookingList => _bookingList;

  bool? _isDriverAccepted;
  bool? get isDriverAccepted => _isDriverAccepted;

  List<Map<String, dynamic>> _messages = [];
  List<Map<String, dynamic>> get messages => _messages;

  List<Map<String, dynamic>> _conversationList = [];
  List<Map<String, dynamic>> get conversationList => _conversationList;

  Map<String, dynamic>? _lastConversation;
  Map<String, dynamic>? get lastConversation => _lastConversation;

  bool? _isCheckedUserOnline;
  bool? get isCheckedUserOnline => _isCheckedUserOnline;

  String _checkedUserId = '';
  String get checkedUserId => _checkedUserId;

  Map<String, double>? _lastDriverLocation;
  Map<String, double>? get lastDriverLocation => _lastDriverLocation;

  SocketProvider({bool enableLifecycleReconnect = true})
      : _enableLifecycleReconnect = enableLifecycleReconnect {
    WidgetsBinding.instance.addObserver(this);
  }

  void _logSocket(String text) {
    debugPrint('SocketProvider => $text');
  }

  void _logSocketErrorThrottled(String message) {
    final now = DateTime.now();
    if (_lastSocketErrorLogAt != null &&
        now.difference(_lastSocketErrorLogAt!).inSeconds < 5) {
      return;
    }
    _lastSocketErrorLogAt = now;
    print(message);
  }

  double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    if (value is String) {
      final raw = value.trim();
      if (raw.isEmpty) return null;

      final normalized = raw.replaceAll(',', '.');
      final direct = double.tryParse(normalized);
      if (direct != null) return direct;

      final match = RegExp(r'-?\d+(?:\.\d+)?').firstMatch(raw);
      if (match != null) {
        return double.tryParse(match.group(0)!);
      }
      return null;
    }
    return double.tryParse(value.toString());
  }

  Map<String, dynamic>? _asMap(dynamic data) {
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return null;
  }

  List<Map<String, dynamic>> _extractMessageList(dynamic data) {
    if (data is List) {
      return data
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }

    final root = _asMap(data);
    if (root == null) return [];

    final candidates = [
      root['data'],
      root['list'],
      root['messages'],
      root['conversation_messages'],
      root['message_list'],
    ];

    for (final candidate in candidates) {
      if (candidate is List) {
        return candidate
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }
      final nested = _asMap(candidate);
      if (nested != null && nested['list'] is List) {
        final list = nested['list'] as List;
        return list
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }
    }

    return [];
  }

  List<Map<String, dynamic>> _extractConversationList(dynamic data) {
    if (data is List) {
      return data
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }

    final root = _asMap(data);
    if (root == null) return [];

    final candidates = [
      root['data'],
      root['list'],
      root['conversation_list'],
      root['conversations'],
    ];

    for (final candidate in candidates) {
      if (candidate is List) {
        return candidate
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }

      final nested = _asMap(candidate);
      if (nested != null) {
        final nestedList =
            nested['list'] ?? nested['conversation_list'] ?? nested['data'];
        if (nestedList is List) {
          return nestedList
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        }
      }
    }

    return [];
  }

  Map<String, dynamic>? _extractIncomingMessage(dynamic data) {
    final root = _asMap(data);
    if (root == null) return null;

    // Conversation metadata packet, not an actual chat bubble.
    if (root['conversation_data'] is Map && root['message'] == null) {
      return null;
    }

    if (root['newObj'] != null) {
      return _asMap(root['newObj']);
    }

    if (root['data'] != null) {
      final dataMap = _asMap(root['data']);
      if (dataMap != null && dataMap['message'] != null) {
        return dataMap;
      }
    }

    return root;
  }

  void _upsertConversationFromPacket(dynamic data) {
    final root = _asMap(data);
    if (root == null) return;

    final packet = _asMap(root['conversation_data']);
    if (packet == null) return;

    final id = (packet['conversation_id'] ?? packet['_id'] ?? '')
        .toString()
        .trim();
    if (id.isEmpty) return;

    final conversation = <String, dynamic>{
      '_id': id,
      'sender_id': packet['sender_id'],
      'receiver_id': packet['receiver_id'],
      'sender_model': packet['sender_model'],
      'receiver_model': packet['receiver_model'],
      'last_message': packet['last_message'],
      'message_type': packet['message_type'],
      'receiver_name': packet['receiver_name'],
      'receiver_image': packet['receiver_image'],
      'sender_name': packet['sender_name'],
      'sender_image': packet['sender_image'],
      'date': packet['date'],
      'time': packet['time'],
    };

    final index =
        _conversationList.indexWhere((e) => (e['_id'] ?? '').toString() == id);
    if (index == -1) {
      _conversationList.insert(0, conversation);
    } else {
      _conversationList[index] = conversation;
    }
  }

  String _messageContextKey(Map<String, dynamic> message) {
    final conversationId = message['conversation_id']?.toString() ?? '';
    if (conversationId.isNotEmpty) return conversationId;
    return message['booking_id']?.toString() ?? '';
  }

  void _logMessagesSnapshot(String source) {
    log('[$source] complete message list count=${_messages.length}');
    log("check socket message and all =====>>>>$_messages");
    log("check socket message and all =====>>>>$conversationList");
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (!_enableLifecycleReconnect) return;
    if (state == AppLifecycleState.resumed) {
      _reconnectIfLoggedIn();
    }
  }

  Future<void> _reconnectIfLoggedIn() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userDetails = prefs.getString('user_details');

      if (userDetails != null && userDetails.isNotEmpty) {
        final data = json.decode(userDetails);
        final String? newUserId =
            (data['user_id'] ?? data['_id'] ?? data['data']?['_id'])
                ?.toString();

        if (newUserId != null && newUserId.isNotEmpty) {
          userId = newUserId;
          await initSocket(AppConstant.token);
        }
      }
    } catch (e) {
      print('Reconnect check error: $e');
    }
  }

  Future<void> initSocket(String jwtToken) async {
    _logSocket('initSocket called, hasSocket=${socket != null}');
    if (socket != null && socket!.connected) {
      _logSocket('socket already connected, refreshing listeners');
      _setupListeners();
      return;
    }
    if (socket != null && !socket!.connected) {
      _logSocket('disposing stale disconnected socket before re-init');
      socket!.clearListeners();
      socket!.disconnect();
      socket!.dispose();
      socket = null;
    }

    if (jwtToken.isEmpty) {
      _logSocket('Token empty, socket not connecting');
      return;
    }

    const String baseUrl = 'https://hii.life';
    const String socketPath = '/app/server/socket.io';

    socket = IO.io(
      baseUrl,
      IO.OptionBuilder()
          .setTransports(['websocket'])
          .setPath(socketPath)
          .setQuery({'token': jwtToken})
          .enableForceNew()
          .enableReconnection()
          .setReconnectionAttempts(5)
          .setReconnectionDelay(2000)
          .build(),
    );

    _setupListeners();
    _logSocket('new socket connect attempt');
    socket!.connect();
  }

  void _setupListeners() {
    if (socket == null) return;
    socket!.clearListeners();

    socket!.onConnect((_) {
      _logSocket('onConnect id=${socket?.id}');
      _isConnected = true;
      _reconnectTimer?.cancel();
      if (_pendingConversationMessages.isNotEmpty) {
        final pending = List<Map<String, dynamic>>.from(
          _pendingConversationMessages,
        );
        _pendingConversationMessages.clear();
        for (final item in pending) {
          _logSocket('flush queued send_message(conversation) => $item');
          socket!.emit('send_message', item);
        }
      }
      notifyListeners();
    });

    socket!.onDisconnect((reason) {
      _logSocket('onDisconnect => $reason');
      _isConnected = false;
      _scheduleReconnect();
      notifyListeners();
    });

    socket!.on('booking_status', (data) {
      _logSocket('on booking_status => $data');
      final root = _asMap(data);
      _isDriverAccepted = root?['is_driver_accepted'] == true;
      notifyListeners();
    });

    socket!.onConnectError((err) {
      _logSocketErrorThrottled('Socket connect error: $err');
      _isConnected = false;
      _scheduleReconnect();
      notifyListeners();
    });

    socket!.onError((err) {
      _logSocketErrorThrottled('Socket error: $err');
      _isConnected = false;
      _scheduleReconnect();
      notifyListeners();
    });

    socket!.onReconnect((attempt) {
      _logSocket('onReconnect attempt=$attempt');
      // Do not mark connected here; on some networks this fires before
      // the transport is fully ready. We rely on onConnect for true-ready state.
    });

    socket!.on('user_status', (data) {
      _logSocket('on user_status => $data');
      final root = _asMap(data);
      if (root == null) return;

      final dynamic onlineRaw = root['online'] ??
          root['is_online'] ??
          root['isOnline'] ??
          root['status'] ??
          root['data']?['online'];

      if (onlineRaw is bool) {
        _isCheckedUserOnline = onlineRaw;
      } else if (onlineRaw is num) {
        _isCheckedUserOnline = onlineRaw == 1;
      } else if (onlineRaw is String) {
        final normalized = onlineRaw.toLowerCase().trim();
        _isCheckedUserOnline =
            normalized == 'online' || normalized == 'true' || normalized == '1';
      }

      _checkedUserId =
          (root['check_user_id'] ?? root['user_id'] ?? '').toString();
      notifyListeners();
    });

    socket!.on('get_conversation_list', (data) {
      _logSocket('on get_conversation_list => $data');
      _conversationList = _extractConversationList(data);
      print(
          'get_conversation_list parsed count=${_conversationList.length} raw=$data');
      notifyListeners();
    });

    socket!.on('last_conversation', (data) {
      _logSocket('on last_conversation => $data');
      final root = _asMap(data);
      if (root == null) return;

      _lastConversation = root;

      final candidate = _extractIncomingMessage(data);
      if (candidate != null) {
        _messages.add(candidate);
      }

      notifyListeners();
    });

    socket!.on('get_message_list', (data) {
      _logSocket('on get_message_list => $data');
      final newMessages = _extractMessageList(data).reversed.toList();

      if (newMessages.isEmpty) {
        _hasMore = false;
        return;
      }

      if (_currentPage == 1) {
        _messages = newMessages;
      } else {
        _messages = [...newMessages, ..._messages];
      }

      _logMessagesSnapshot('get_message_list');
      notifyListeners();
    });

    socket!.on('send_message', (data) {
      _logSocket('on send_message => $data');
      _upsertConversationFromPacket(data);
      final incoming = _extractIncomingMessage(data);
      if (incoming == null) return;

      final incomingMessage = incoming['message']?.toString() ?? '';
      final incomingContext = _messageContextKey(incoming);
      final incomingSenderId = (incoming['sender_id'] is Map)
          ? (incoming['sender_id']['_id'] ?? '').toString()
          : (incoming['sender_id'] ?? '').toString();
      final incomingReceiverId = (incoming['receiver_id'] is Map)
          ? (incoming['receiver_id']['_id'] ?? '').toString()
          : (incoming['receiver_id'] ?? '').toString();

      final index = _messages.indexWhere((m) {
        final id = m['_id']?.toString() ?? '';
        final localContext = _messageContextKey(m);
        final localSenderId = (m['sender_id'] ?? '').toString();
        final localReceiverId = (m['receiver_id'] ?? '').toString();
        final sameConversation = localContext == incomingContext;
        final contextResolvedAfterCreate = localContext.isEmpty &&
            incomingContext.isNotEmpty &&
            localSenderId == incomingSenderId &&
            localReceiverId == incomingReceiverId;
        return id.startsWith('tmp_') &&
            (m['message']?.toString() ?? '') == incomingMessage &&
            (sameConversation || contextResolvedAfterCreate);
      });

      if (index != -1) {
        _messages[index] = incoming;
      } else {
        _messages.add(incoming);
      }

      _logMessagesSnapshot('send_message');
      notifyListeners();
    });

    socket!.on('receive_message', (data) {
      _logSocket('on receive_message => $data');
      final incoming = _extractIncomingMessage(data);
      if (incoming == null) return;

      _messages.add(incoming);
      _logMessagesSnapshot('receive_message');
      notifyListeners();
    });

    socket!.on('driver_live_location', (data) {
      _logSocket('on driver_live_location => $data');
      if (data == null) return;

      try {
        final root = _asMap(data);
        final nestedData = _asMap(root?['data']);
        final driverObj = _asMap(nestedData?['driver_id']);

        final lat = _toDouble(root?['latitude']) ??
            _toDouble(nestedData?['latitude']) ??
            _toDouble(driverObj?['latitude']);
        final lng = _toDouble(root?['longitude']) ??
            _toDouble(nestedData?['longitude']) ??
            _toDouble(driverObj?['longitude']);

        if (lat == null || lng == null) {
          return;
        }

        _lastDriverLocation = {'lat': lat, 'lng': lng};
        notifyListeners();
      } catch (e) {
        print('Error parsing driver location: $e');
      }
    });
  }

  void disconnect() {
    _reconnectTimer?.cancel();
    if (socket != null) {
      _logSocket('disconnect called');
      socket!.clearListeners();
      socket!.disconnect();
      socket!.dispose();
      socket = null;
      _isConnected = false;
      _pendingConversationMessages.clear();
      notifyListeners();
    }
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 2), () {
      if (socket == null) {
        if (AppConstant.token.trim().isNotEmpty) {
          initSocket(AppConstant.token);
        }
      } else if (!socket!.connected) {
        _logSocket('scheduled reconnect attempt');
        socket!.connect();
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    disconnect();
    super.dispose();
  }

  void emitBookingStatus({
    required String userId,
    required String bookingId,
  }) {
    if (socket == null || !socket!.connected) {
      print('Socket not connected, cannot emit booking_status');
      return;
    }

    socket!.emit('check_booking');
  }

  bool emitUserStatus({
    required String userId,
    required String checkUserId,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit user_status blocked, socket disconnected');
      return false;
    }

    final data = {
      'user_id': userId,
      'check_user_id': checkUserId,
    };

    _checkedUserId = checkUserId;
    _logSocket('emit user_status => $data');
    socket!.emit('user_status', data);
    return true;
  }

  bool getConversationList({
    required String userId,
    int page = 1,
    int limit = 50,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit get_conversation_list blocked, socket disconnected');
      return false;
    }

    final data = {
      'user_id': userId,
      'page': page,
      'limit': limit,
    };

    log('SOCKET EMIT get_conversation_list => $data');
    _logSocket('emit get_conversation_list => $data');
    socket!.emit('get_conversation_list', data);
    return true;
  }

  void getMessageList({
    required String userId,
    required String bookingId,
    int page = 1,
    int limit = 30,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit get_message_list blocked, socket disconnected');
      return;
    }

    final data = {
      'user_id': userId,
      'booking_id': bookingId,
      'page': page,
      'limit': limit,
    };

    _logSocket('emit get_message_list => $data');
    socket!.emit('get_message_list', data);
  }

  void getConversationMessageList({
    required String userId,
    required String conversationId,
    int page = 1,
    int limit = 50,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket(
          'emit get_conversation_message_list blocked, socket disconnected');
      return;
    }

    final data = {
      'user_id': userId,
      'conversation_id': conversationId,
      'page': page,
      'limit': limit,
    };

    _logSocket('emit get_conversation_message_list => $data');
    socket!.emit('get_message_list', data);
  }

  void joinChat({
    required String userId,
    required String bookingId,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit join_chat(booking) blocked, socket disconnected');
      return;
    }

    _currentPage = 1;
    _hasMore = true;
    _messages = [];

    final data = {
      'user_id': userId,
      'booking_id': bookingId,
    };

    _logSocket('emit join_chat(booking) => $data');
    socket!.emit('join_chat', data);

    getMessageList(
      userId: userId,
      bookingId: bookingId,
      page: 1,
      limit: 30,
    );
  }

  void joinConversationChat({
    required String userId,
    required String conversationId,
    int firstPageLimit = 50,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit join_chat(conversation) blocked, socket disconnected');
      return;
    }

    _currentPage = 1;
    _hasMore = true;
    _messages = [];

    final data = {
      'user_id': userId,
      'conversation_id': conversationId,
    };

    _logSocket('emit join_chat(conversation) => $data');
    socket!.emit('join_chat', data);

    getConversationMessageList(
      userId: userId,
      conversationId: conversationId,
      page: 1,
      limit: firstPageLimit,
    );
  }

  void leaveChat({
    required String userId,
    required String bookingId,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit leave_chat(booking) blocked, socket disconnected');
      return;
    }

    final data = {
      'user_id': userId,
      'booking_id': bookingId,
    };

    _logSocket('emit leave_chat(booking) => $data');
    socket!.emit('leave_chat', data);
  }

  void leaveConversationChat({
    required String userId,
    required String conversationId,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit leave_chat(conversation) blocked, socket disconnected');
      return;
    }

    final data = {
      'user_id': userId,
      'conversation_id': conversationId,
    };

    _logSocket('emit leave_chat(conversation) => $data');
    socket!.emit('leave_chat', data);
  }

  void sendMessage({
    required String senderId,
    required String receiverId,
    required String bookingId,
    required String message,
  }) {
    if (socket == null || !socket!.connected) {
      _logSocket('emit send_message(booking) blocked, socket disconnected');
      return;
    }

    final now = DateTime.now();
    final formattedTime =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    final tempId = 'tmp_${now.microsecondsSinceEpoch}';

    final data = {
      '_id': tempId,
      'sender_id': senderId,
      'receiver_id': receiverId,
      'booking_id': bookingId,
      'message': message,
      'type': 'message',
      'files': [],
      'time': formattedTime,
      'createdAt': now.toIso8601String(),
    };

    _messages.add(Map<String, dynamic>.from(data));
    notifyListeners();

    _logSocket('emit send_message(booking) => $data');
    socket!.emit('send_message', data);
  }

  void sendConversationMessage({
    required String senderId,
    required String senderName,
    required String senderImage,
    required String receiverId,
    required String receiverName,
    required String receiverImage,
    required String conversationId,
    required String message,
    String senderModel = 'User',
    String receiverModel = 'Admin',
    String type = 'message',
    List<dynamic> files = const [],
  }) {
    final now = DateTime.now();
    final formattedTime =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    final tempId = 'tmp_${now.microsecondsSinceEpoch}';

    final data = {
      '_id': tempId,
      'sender_id': senderId,
      'sender_name': senderName,
      'sender_image': senderImage,
      'receiver_id': receiverId,
      'receiver_name': receiverName,
      'receiver_image': receiverImage,
      'receiver_model': receiverModel,
      'sender_model': senderModel,
      'message': message,
      'type': type,
      'files': files,
      'time': formattedTime,
      'createdAt': now.toIso8601String(),
    };
    if (conversationId.trim().isNotEmpty) {
      data['conversation_id'] = conversationId.trim();
    }

    _messages.add(Map<String, dynamic>.from(data));
    notifyListeners();

    if (socket == null || !socket!.connected) {
      _logSocket(
          'queue send_message(conversation), socket disconnected => $data');
      _pendingConversationMessages.add(Map<String, dynamic>.from(data));
      if (socket == null && AppConstant.token.trim().isNotEmpty) {
        initSocket(AppConstant.token);
      } else {
        socket?.connect();
      }
      return;
    }

    _logSocket('emit send_message(conversation) => $data');
    socket!.emit('send_message', data);

    log("send dataaa to socket=======>>>>>>$data");
  }

  Future<List<String>> uploadChatMediaFiles({
    required List<String> localFilePaths,
    String endpoint =
        'https://hii.life/app/server/api/v1/admin/user/image_uplod',
    String fieldName = 'image',
  }) async {
    final paths = localFilePaths
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList(growable: false);
    if (paths.isEmpty) return <String>[];

    try {
      final uri = Uri.parse(endpoint);
      final request = http.MultipartRequest('POST', uri);

      if (AppConstant.token.trim().isNotEmpty) {
        request.headers['Authorization'] = 'Bearer ${AppConstant.token}';
      }

      for (final path in paths) {
        final file = File(path);
        if (!file.existsSync()) continue;
        request.files.add(await http.MultipartFile.fromPath(fieldName, path));
      }

      if (request.files.isEmpty) return <String>[];

      final streamed = await request.send();
      final response = await http.Response.fromStream(streamed);
      if (response.statusCode != 200) {
        log('uploadChatMediaFiles failed code=${response.statusCode} body=${response.body}');
        return <String>[];
      }

      final dynamic decoded = jsonDecode(response.body);
      if (decoded is! Map || decoded['success'] != true) {
        return <String>[];
      }

      final dynamic data = decoded['data'];
      if (data is! List) return <String>[];

      final List<String> uploaded = <String>[];
      for (final item in data) {
        if (item is String && item.trim().isNotEmpty) {
          uploaded.add(item.trim());
          continue;
        }
        if (item is Map) {
          final filename =
              (item['filename'] ?? item['file'] ?? item['url'] ?? '')
                  .toString()
                  .trim();
          if (filename.isNotEmpty) uploaded.add(filename);
        }
      }
      return uploaded;
    } catch (e) {
      log('uploadChatMediaFiles error=$e');
      return <String>[];
    }
  }

  String _resolveMediaType(List<String> fileNames) {
    if (fileNames.isEmpty) return 'message';
    bool hasVideo = false;
    bool hasDocument = false;

    for (final raw in fileNames) {
      final file = raw.toLowerCase().trim();
      if (file.endsWith('.mp4') ||
          file.endsWith('.mov') ||
          file.endsWith('.avi') ||
          file.endsWith('.mkv') ||
          file.endsWith('.webm')) {
        hasVideo = true;
      } else if (file.endsWith('.pdf') ||
          file.endsWith('.doc') ||
          file.endsWith('.docx') ||
          file.endsWith('.xls') ||
          file.endsWith('.xlsx') ||
          file.endsWith('.txt')) {
        hasDocument = true;
      }
    }

    if (hasVideo) return 'video';
    if (hasDocument) return 'pdf';
    return 'image';
  }

  Future<bool> sendConversationMediaMessage({
    required String senderId,
    required String senderName,
    required String senderImage,
    required String receiverId,
    required String receiverName,
    required String receiverImage,
    required String conversationId,
    required List<String> localFilePaths,
    String senderModel = 'User',
    String receiverModel = 'Admin',
    String uploadEndpoint =
        'https://hii.life/app/server/api/v1/admin/user/image_uplod',
  }) async {
    final uploadedFiles = await uploadChatMediaFiles(
      localFilePaths: localFilePaths,
      endpoint: uploadEndpoint,
    );
    if (uploadedFiles.isEmpty) return false;

    final type = _resolveMediaType(uploadedFiles);
    sendConversationMessage(
      senderId: senderId,
      senderName: senderName,
      senderImage: senderImage,
      receiverId: receiverId,
      receiverName: receiverName,
      receiverImage: receiverImage,
      conversationId: conversationId,
      message: '',
      senderModel: senderModel,
      receiverModel: receiverModel,
      type: type,
      files: uploadedFiles,
    );
    return true;
  }

  void loadMoreMessages({
    required String userId,
    required String bookingId,
    int limit = 30,
  }) {
    if (_isLoadingMore || !_hasMore) return;

    _isLoadingMore = true;
    _currentPage += 1;

    getMessageList(
      userId: userId,
      bookingId: bookingId,
      page: _currentPage,
      limit: limit,
    );

    Future.delayed(const Duration(milliseconds: 500), () {
      _isLoadingMore = false;
    });
  }

  void loadMoreConversationMessages({
    required String userId,
    required String conversationId,
    int limit = 50,
  }) {
    if (_isLoadingMore || !_hasMore) return;

    _isLoadingMore = true;
    _currentPage += 1;

    getConversationMessageList(
      userId: userId,
      conversationId: conversationId,
      page: _currentPage,
      limit: limit,
    );

    Future.delayed(const Duration(milliseconds: 500), () {
      _isLoadingMore = false;
    });
  }
}
