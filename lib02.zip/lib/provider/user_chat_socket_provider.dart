import 'dart:async';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '/utilities/app_constant.dart';

class UserChatSocketProvider extends ChangeNotifier {
  IO.Socket? _socket;
  Timer? _reconnectTimer;
  int _reconnectAttempts = 0;
  bool _isRecreatingSocket = false;
  // ── State ──
  bool _isConnected = false;
  bool get isConnected => _isConnected;

  bool _isLoadingMore = false;
  bool get isLoadingMore => _isLoadingMore;

  final List<Map<String, dynamic>> _messages = [];
  List<Map<String, dynamic>> get messages => _messages;

  final List<Map<String, dynamic>> _conversationList = [];
  List<Map<String, dynamic>> get conversationList => _conversationList;

  final List<Map<String, dynamic>> _pendingMessages = [];
  String _activeConversationUserId = '';
  String _activeConversationId = '';
  int _activeConversationLimit = 50;

  Map<String, dynamic>? _lastConversation;
  Map<String, dynamic>? get lastConversation => _lastConversation;

  bool? _isCheckedUserOnline;
  bool? get isCheckedUserOnline => _isCheckedUserOnline;

  String _checkedUserId = '';
  String get checkedUserId => _checkedUserId;

  // ─────────────────────────────────────────────────────────────────
  // initSocket
  // ─────────────────────────────────────────────────────────────────
  Future<void> initSocket(String jwtToken) async {
    debugPrint('UserChat => initSocket, hasSocket=${_socket != null}');

    if (jwtToken.isEmpty) {
      debugPrint('UserChat => token empty, aborting');
      return;
    }

    if (_socket != null) {
      _setupListeners();
      if (_socket!.connected) {
        debugPrint('UserChat => already connected id=${_socket?.id}');
        _isConnected = true;
        _reconnectAttempts = 0;
      } else {
        if (_isRecreatingSocket) return;
        if (_reconnectAttempts >= 2) {
          _recreateSocketAndConnect();
        } else {
          debugPrint('UserChat => existing socket reconnect attempt');
          _socket!.connect();
        }
      }
      return;
    }

    debugPrint('UserChat => creating socket...');
    _socket = IO.io(
      'https://hii.life',
      IO.OptionBuilder()
          .setTransports(['websocket', 'polling'])
          .setPath('/app/server/socket.io')
          .setQuery({'token': jwtToken})
          .enableForceNew()
          .enableReconnection()
          .setReconnectionAttempts(20)
          .setReconnectionDelay(2000)
          .setTimeout(20000)
          .build(),
    );

    _setupListeners();
    debugPrint('UserChat => socket.connect() calling...');
    _socket!.connect();
  }

  // ─────────────────────────────────────────────────────────────────
  // Listeners
  // ─────────────────────────────────────────────────────────────────
  void _setupListeners() {
    if (_socket == null) return;
    _socket!.clearListeners();

    _socket!.onConnect((_) {
      debugPrint('UserChat => ✅ CONNECTED id=${_socket?.id}');
      _isConnected = true;
      _reconnectAttempts = 0;
      _reconnectTimer?.cancel();
      _rejoinActiveConversationIfAny();
      _flushPending();
      _safeNotify();
    });

    _socket!.onDisconnect((reason) {
      debugPrint('UserChat => ❌ disconnected: $reason');
      _isConnected = false;
      _scheduleReconnect();
      _safeNotify();
    });

    _socket!.onConnectError((err) {
      debugPrint('UserChat => ❌ connect error: $err');
      _isConnected = false;
      _scheduleReconnect();
      _safeNotify();
    });

    _socket!.onError((err) {
      debugPrint('UserChat => ❌ error: $err');
      _isConnected = false;
      _scheduleReconnect();
      _safeNotify();
    });

    _socket!.onReconnect((attempt) {
      debugPrint('UserChat => reconnect success attempt=$attempt');
      _isConnected = true;
      _reconnectAttempts = 0;
      _reconnectTimer?.cancel();
      _rejoinActiveConversationIfAny();
      _flushPending();
      _safeNotify();
    });

    _socket!.on('user_status', (data) {
      debugPrint('UserChat => user_status: $data');
      final root = _asMap(data);
      if (root == null) return;
      final dynamic raw = root['online'] ??
          root['is_online'] ??
          root['isOnline'] ??
          root['status'] ??
          root['data']?['online'];
      if (raw is bool)
        _isCheckedUserOnline = raw;
      else if (raw is num)
        _isCheckedUserOnline = raw == 1;
      else if (raw is String) {
        final n = raw.toLowerCase().trim();
        _isCheckedUserOnline = n == 'online' || n == 'true' || n == '1';
      }
      _checkedUserId =
          (root['check_user_id'] ?? root['user_id'] ?? '').toString();
      notifyListeners();
    });

    _socket!.on('get_conversation_list', (data) {
      debugPrint('UserChat => get_conversation_list');
      _conversationList
        ..clear()
        ..addAll(_extractList(data));
      log('UserChat get_conversation_list count=${_conversationList.length}');
      notifyListeners();
    });

    _socket!.on('get_message_list', (data) {
      debugPrint('UserChat => get_message_list');
      final incoming = _extractMessages(data).reversed.toList();
      if (incoming.isEmpty) return;
      _messages
        ..clear()
        ..addAll(incoming);
      log('UserChat get_message_list count=${_messages.length}');
      notifyListeners();
    });

    _socket!.on('send_message', (data) {
      debugPrint('UserChat => send_message ack: $data');
      _upsertConversation(data);
      final incoming = _extractMessage(data);
      if (incoming == null) return;

      final msg = incoming['message']?.toString() ?? '';
      final convId =
          (incoming['conversation_id'] ?? incoming['conversationId'] ?? '')
              .toString()
              .trim();
      final sender = _getId(incoming['sender_id'] ?? incoming['senderId']);
      final receiver =
          _getId(incoming['receiver_id'] ?? incoming['receiverId']);

      final idx = _messages.indexWhere((m) {
        if (!(m['_id']?.toString() ?? '').startsWith('tmp_')) return false;
        if ((m['message']?.toString() ?? '') != msg) return false;
        final localConv = (m['conversation_id'] ?? m['conversationId'] ?? '')
            .toString()
            .trim();
        if (localConv.isNotEmpty && convId.isNotEmpty)
          return localConv == convId;
        return _getId(m['sender_id'] ?? m['senderId']) == sender &&
            _getId(m['receiver_id'] ?? m['receiverId']) == receiver;
      });

      if (idx != -1) {
        _messages[idx] = incoming;
      } else {
        _messages.add(incoming);
      }

      log('UserChat send_message ack, messages=${_messages.length}');
      notifyListeners();
    });

    _socket!.on('receive_message', (data) {
      debugPrint('UserChat => receive_message: $data');
      final incoming = _extractMessage(data);
      if (incoming == null) return;
      _messages.add(incoming);
      log('UserChat receive_message, messages=${_messages.length}');
      notifyListeners();
    });

    _socket!.on('last_conversation', (data) {
      debugPrint('UserChat => last_conversation');
      _lastConversation = _asMap(data);
      final m = _extractMessage(data);
      if (m != null) _messages.add(m);
      notifyListeners();
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // Safe notifyListeners (avoid crash during build/dispose)
  // ─────────────────────────────────────────────────────────────────
  void _safeNotify() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      try {
        notifyListeners();
      } catch (_) {}
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // Reconnect
  // ─────────────────────────────────────────────────────────────────
  void _scheduleReconnect() {
    if (_reconnectTimer?.isActive ?? false) return;
    _reconnectTimer = Timer(const Duration(seconds: 3), () {
      if (_isConnected) return;
      if (_isRecreatingSocket) return;
      if (_socket == null) {
        if (AppConstant.token.trim().isNotEmpty) {
          initSocket(AppConstant.token);
        }
        return;
      }
      if (!_socket!.connected) {
        _reconnectAttempts++;
        if (_reconnectAttempts >= 3) {
          _recreateSocketAndConnect();
          return;
        }
        debugPrint('UserChat => reconnect attempt');
        _socket!.connect();
      }
    });
  }

  Future<void> _recreateSocketAndConnect() async {
    if (_isRecreatingSocket) return;
    if (AppConstant.token.trim().isEmpty) return;

    _isRecreatingSocket = true;
    _reconnectAttempts = 0;
    debugPrint('UserChat => recreating socket after reconnect failures');

    if (_socket != null) {
      try {
        _socket!.clearListeners();
      } catch (_) {}
      try {
        _socket!.disconnect();
      } catch (_) {}
      try {
        _socket!.dispose();
      } catch (_) {}
      _socket = null;
    }

    await Future.delayed(const Duration(milliseconds: 300));
    await initSocket(AppConstant.token);
    _isRecreatingSocket = false;
  }

  // ─────────────────────────────────────────────────────────────────
  // Flush pending after reconnect
  // ─────────────────────────────────────────────────────────────────
  void _flushPending() {
    if (_socket == null || !_socket!.connected) return;
    final pending = List<Map<String, dynamic>>.from(_pendingMessages);
    _pendingMessages.clear();
    for (final item in pending) {
      debugPrint('UserChat => flushing pending: $item');
      _socket!.emit('send_message', item);
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // Public methods
  // ─────────────────────────────────────────────────────────────────

  bool emitUserStatus({required String userId, required String checkUserId}) {
    if (_socket == null || !_socket!.connected) {
      debugPrint('UserChat => user_status blocked, not connected');
      return false;
    }
    _checkedUserId = checkUserId;
    _socket!
        .emit('user_status', {'user_id': userId, 'check_user_id': checkUserId});
    return true;
  }

  bool getConversationList(
      {required String userId, int page = 1, int limit = 50}) {
    if (_socket == null || !_socket!.connected) {
      debugPrint('UserChat => get_conversation_list blocked, not connected');
      return false;
    }
    _socket!.emit('get_conversation_list',
        {'user_id': userId, 'page': page, 'limit': limit});
    return true;
  }

  void joinConversationChat({
    required String userId,
    required String conversationId,
    int firstPageLimit = 50,
  }) {
    _activeConversationUserId = userId.trim();
    _activeConversationId = conversationId.trim();
    _activeConversationLimit = firstPageLimit;

    if (_socket == null || !_socket!.connected) {
      debugPrint('UserChat => join_chat blocked, not connected');
      return;
    }
    _emitJoinAndFetchConversation(
      userId: _activeConversationUserId,
      conversationId: _activeConversationId,
      firstPageLimit: _activeConversationLimit,
      clearMessages: true,
    );
  }

  void leaveConversationChat(
      {required String userId, required String conversationId}) {
    if (_socket == null || !_socket!.connected) return;
    _socket!.emit(
        'leave_chat', {'user_id': userId, 'conversation_id': conversationId});
    if (_activeConversationId == conversationId.trim()) {
      _activeConversationId = '';
      _activeConversationUserId = '';
      _activeConversationLimit = 50;
    }
  }

  void loadMoreConversationMessages({
    required String userId,
    required String conversationId,
    int limit = 50,
  }) {
    if (_isLoadingMore || _socket == null || !_socket!.connected) return;
    _socket!.emit('get_message_list', {
      'user_id': userId,
      'conversation_id': conversationId,
      'page': 2,
      'limit': limit,
    });
  }

  void sendConversationMessage({
    required String senderId,
    required String senderName,
    required String senderImage,
    required String receiverId,
    required String receiverName,
    required String receiverImage,
    required String conversationId,
    required String message,
    String senderModel = 'User',
    String receiverModel = 'User',
    String type = 'message',
    List<dynamic> files = const [],
  }) {
    final now = DateTime.now();
    final time =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final tempId = 'tmp_${now.microsecondsSinceEpoch}';

    final data = <String, dynamic>{
      '_id': tempId,
      'sender_id': senderId,
      'sender_name': senderName,
      'sender_image': senderImage,
      'receiver_id': receiverId,
      'receiver_name': receiverName,
      'receiver_image': receiverImage,
      'sender_model': senderModel,
      'receiver_model': 'User',
      'message': message,
      'type': type,
      'files': files,
      'time': time,
      'createdAt': now.toIso8601String(),
    };

    if (conversationId.trim().isNotEmpty) {
      data['conversation_id'] = conversationId.trim();
    }

    // Optimistic UI
    _messages.add(Map<String, dynamic>.from(data));
    notifyListeners();

    if (_socket == null || !_socket!.connected) {
      debugPrint('UserChat => not connected, queuing message');
      _pendingMessages.add(Map<String, dynamic>.from(data));
      if (_socket == null && AppConstant.token.trim().isNotEmpty) {
        initSocket(AppConstant.token);
      } else {
        _socket?.connect();
      }
      return;
    }

    debugPrint('UserChat => emit send_message');
    _socket!.emit('send_message', data);
    log('UserChat send dataaa=======>>>>>>$data');
  }

  void _emitJoinAndFetchConversation({
    required String userId,
    required String conversationId,
    required int firstPageLimit,
    bool clearMessages = false,
  }) {
    if (_socket == null || !_socket!.connected) return;
    if (userId.isEmpty || conversationId.isEmpty) return;

    if (clearMessages) {
      _messages.clear();
    }

    _socket!.emit(
        'join_chat', {'user_id': userId, 'conversation_id': conversationId});
    _socket!.emit('get_message_list', {
      'user_id': userId,
      'conversation_id': conversationId,
      'page': 1,
      'limit': firstPageLimit,
    });
    debugPrint('UserChat => joined conversation: $conversationId');
  }

  void _rejoinActiveConversationIfAny() {
    if (_activeConversationUserId.isEmpty || _activeConversationId.isEmpty) {
      return;
    }
    _emitJoinAndFetchConversation(
      userId: _activeConversationUserId,
      conversationId: _activeConversationId,
      firstPageLimit: _activeConversationLimit,
      clearMessages: true,
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // disconnect — safe (no notifyListeners)
  // ─────────────────────────────────────────────────────────────────
  void disconnect() {
    _reconnectTimer?.cancel();
    _isConnected = false;
    _pendingMessages.clear();
    if (_socket != null) {
      debugPrint('UserChat => disconnect');
      _socket!.clearListeners();
      try {
        _socket!.disconnect();
      } catch (_) {}
      try {
        _socket!.dispose();
      } catch (_) {}
      _socket = null;
    }
  }

  @override
  void dispose() {
    disconnect();
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────────────────────────
  Map<String, dynamic>? _asMap(dynamic data) {
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return null;
  }

  String _getId(dynamic raw) {
    if (raw == null) return '';
    if (raw is Map) return (raw['_id'] ?? raw['id'] ?? '').toString().trim();
    return raw.toString().trim();
  }

  List<Map<String, dynamic>> _extractMessages(dynamic data) {
    if (data is List)
      return data
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    final root = _asMap(data);
    if (root == null) return [];
    for (final key in [
      'data',
      'list',
      'messages',
      'conversation_messages',
      'message_list'
    ]) {
      final val = root[key];
      if (val is List)
        return val
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      final nested = _asMap(val);
      if (nested?['list'] is List) {
        return (nested!['list'] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }
    }
    return [];
  }

  List<Map<String, dynamic>> _extractList(dynamic data) {
    if (data is List)
      return data
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    final root = _asMap(data);
    if (root == null) return [];
    for (final key in ['data', 'list', 'conversation_list', 'conversations']) {
      final val = root[key];
      if (val is List)
        return val
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      final nested = _asMap(val);
      if (nested != null) {
        final nl =
            nested['list'] ?? nested['conversation_list'] ?? nested['data'];
        if (nl is List)
          return (nl as List)
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
      }
    }
    return [];
  }

  Map<String, dynamic>? _extractMessage(dynamic data) {
    final root = _asMap(data);
    if (root == null) return null;
    if (root['conversation_data'] is Map && root['message'] == null)
      return null;
    if (root['newObj'] != null) return _asMap(root['newObj']);
    if (root['data'] != null) {
      final d = _asMap(root['data']);
      if (d != null && d['message'] != null) return d;
    }
    return root;
  }

  void _upsertConversation(dynamic data) {
    final root = _asMap(data);
    if (root == null) return;
    final packet = _asMap(root['conversation_data']);
    if (packet == null) return;
    final id =
        (packet['conversation_id'] ?? packet['_id'] ?? '').toString().trim();
    if (id.isEmpty) return;
    final conv = <String, dynamic>{
      '_id': id,
      'sender_id': packet['sender_id'],
      'receiver_id': packet['receiver_id'],
      'sender_model': packet['sender_model'],
      'receiver_model': packet['receiver_model'],
      'last_message': packet['last_message'],
      'message_type': packet['message_type'],
    };
    final idx = _conversationList.indexWhere((e) => (e['_id'] ?? '') == id);
    if (idx == -1)
      _conversationList.insert(0, conv);
    else
      _conversationList[idx] = conv;
  }
}
