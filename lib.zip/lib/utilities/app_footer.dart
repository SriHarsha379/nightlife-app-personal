import 'package:flutter/material.dart';
import 'package:night_life/view/bottom%20navigation/home_Screen.dart';
import 'package:night_life/view/bottom%20navigation/profile1.dart';
import 'package:night_life/view/bottom%20navigation/chats_screen.dart';
import 'package:night_life/view/bottom%20navigation/search_screen.dart';
import 'package:night_life/utilities/page_transition.dart';
import 'package:provider/provider.dart';
import '../view/other/MySplashSection/EventSection/my_events.dart';
import '../view/other/MySplashSection/MembersSection/Members.dart';
import '../view/other/MySplashSection/VenuesSection/my_venue.dart';
import '../provider/socket_provider.dart';
import 'app_color.dart';
import 'app_constant.dart';
import 'app_font.dart';
import 'app_image.dart';
import 'app_language.dart';

class MyAppFooter extends StatefulWidget {
  final int initialIndex;

  const MyAppFooter({super.key, this.initialIndex = 4});

  @override
  State<MyAppFooter> createState() => MyAppFooterState();
}

class MyAppFooterState extends State<MyAppFooter> {
  PageController pageController = PageController(initialPage: 0);
  int selectedIndex = 0;
  int _previousIndex = 0;

  @override
  void initState() {
    pageController = PageController(initialPage: AppConstant.selectFooterIndex);
    selectedIndex = widget.initialIndex;
    _previousIndex = widget.initialIndex;

    // FIX: removed _ensureSocketReady from initState.
    // Socket is managed by post_api_provider (login → forceReconnect)
    // and ChatScreen (on open → initSocket).
    // Calling initSocket here was causing a race condition where the footer
    // connected the socket BEFORE the login flow's forceReconnect finished
    // setting the new user's token, resulting in the old/stale socket session
    // being reused for the new user.

    super.initState();
  }

  final List<Map<String, dynamic>> iconList = [
    {
      "id": 1,
      "icon": AppImage.homeIcon,
    },
    {
      "id": 2,
      "icon": AppImage.searchIcon,
    },
    {
      "id": 3,
      "icon": AppImage.vectionIcon,
    },
    {
      "id": 5,
      "icon": AppImage.chatIcon,
    },
    {
      "id": 4,
      "icon": AppImage.whiteProfileicon,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        transitionBuilder: (Widget child, Animation<double> animation) {
          if (selectedIndex == 2) {
            return child;
          }

          return Container(
            color: AppColor.primaryColor(context),
            child: FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0.3, 0.0),
                  end: Offset.zero,
                ).animate(CurvedAnimation(
                  parent: animation,
                  curve: Curves.easeInOut,
                )),
                child: child,
              ),
            ),
          );
        },
        child: Container(
          key: ValueKey<int>(selectedIndex),
          child: _getCurrentPage(),
        ),
      ),
      floatingActionButton: ValueListenableBuilder<bool>(
        valueListenable: footerVisibilityNotifier,
        builder: (context, isVisible, _) {
          if (!isVisible) return const SizedBox.shrink();
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30.0),
              child: Container(
                width: MediaQuery.of(context).size.width * 78 / 100,
                height: MediaQuery.of(context).size.height * 8 / 100,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: AppColor.themeColor,
                  boxShadow: const [
                    BoxShadow(
                      blurRadius: 4,
                      spreadRadius: 0,
                      color: AppColor.transparentColor,
                      offset: Offset(0, 0),
                    ),
                  ],
                ),
                padding: const EdgeInsets.symmetric(horizontal: 19),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(iconList.length, (index) {
                    double getIconWidth(int index) {
                      switch (index) {
                        case 0:
                          return MediaQuery.of(context).size.width * 8 / 100;
                        case 1:
                          return MediaQuery.of(context).size.width * 7 / 100;
                        case 2:
                          return MediaQuery.of(context).size.width * 7 / 100;
                        case 3:
                          return MediaQuery.of(context).size.width * 5.5 / 100;
                        default:
                          return MediaQuery.of(context).size.width * 5 / 100;
                      }
                    }

                    double getIconHeight(int index) {
                      switch (index) {
                        case 0:
                          return MediaQuery.of(context).size.width * 7 / 100;
                        case 1:
                          return MediaQuery.of(context).size.width * 6 / 100;
                        case 2:
                          return MediaQuery.of(context).size.width * 6 / 100;
                        case 3:
                          return MediaQuery.of(context).size.width * 6 / 100;
                        default:
                          return MediaQuery.of(context).size.width * 5 / 100;
                      }
                    }

                    return GestureDetector(
                      onTap: () {
                        onItemTapped(index);
                      },
                      child: Container(
                        width: selectedIndex == index
                            ? MediaQuery.of(context).size.width * 12.4 / 100
                            : MediaQuery.of(context).size.width * 12.4 / 100,
                        height: selectedIndex == index
                            ? MediaQuery.of(context).size.width * 10 / 100
                            : MediaQuery.of(context).size.width * 12.4 / 100,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: selectedIndex == index
                              ? const Color.fromRGBO(255, 28, 192, 0.6)
                              : Colors.transparent,
                          boxShadow: selectedIndex == index
                              ? [
                                  BoxShadow(
                                    color:
                                        AppColor.buttonColor.withOpacity(1.0),
                                    blurRadius: 20,
                                    spreadRadius: 3,
                                    offset: const Offset(0, 1),
                                  ),
                                ]
                              : [],
                        ),
                        alignment: Alignment.center,
                        child: Image.asset(
                          iconList[index]['icon'],
                          width: getIconWidth(index),
                          height: getIconHeight(index),
                          color: Colors.white,
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _getCurrentPage() {
    switch (selectedIndex) {
      case 0:
        return const Home();
      case 1:
        return const SearchScreen();
      case 2:
        return _getPreviousPage();
      case 3:
        return const ChatScreen();
      case 4:
        return const Profile1();
      default:
        return const Home();
    }
  }

  Widget _getPreviousPage() {
    switch (_previousIndex) {
      case 0:
        return const Home();
      case 1:
        return const SearchScreen();
      case 3:
        return const ChatScreen();
      case 4:
        return const Profile1();
      default:
        return const Home();
    }
  }

  void onItemTapped(int index) {
    if (index == 2) {
      documenttypebottomsheet(context);
    } else {
      setState(() {
        _previousIndex = selectedIndex;
        selectedIndex = index;
      });
      // FIX: removed _ensureSocketReady() call here.
      // ChatScreen handles its own socket init on open.
      // Calling it from the footer was connecting the socket
      // before ChatScreen could properly set up its listeners,
      // causing the onConnect event to be missed.
    }
  }

  void documenttypebottomsheet(BuildContext context) {
    final size = MediaQuery.of(context).size;

    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(),
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setStateBottomSheet) {
          return Container(
            width: MediaQuery.of(context).size.width * 100 / 100,
            height: MediaQuery.of(context).size.height * 78 / 100,
            color: Colors.transparent,
            child: Column(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 100 / 100,
                  height: MediaQuery.of(context).size.height * 78 / 100,
                  child: Column(
                    children: [
                      Expanded(
                        flex: 1,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: AppColor.backgroundGradientcolor(context),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(45),
                              topRight: Radius.circular(45),
                            ),
                          ),
                          width: size.width * 1.0,
                          child: Column(
                            children: [
                              SizedBox(height: size.height * 0.02),
                              Container(
                                width: size.width * 0.88,
                                child: Column(
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Image.asset(
                                        AppImage.dashIcon,
                                        height: size.height * 0.5 / 100,
                                        width: size.width * 22 / 100,
                                        fit: BoxFit.fill,
                                        color: AppColor.secondryColor(context),
                                      ),
                                    ),
                                    SizedBox(height: size.height * 4 / 100),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          0.84,
                                      child: Text(
                                        AppLanguage.myspacetext[language],
                                        style: TextStyle(
                                          color:
                                              AppColor.secondryColor(context),
                                          fontFamily: AppFont.fontFamily,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 23,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          0.84,
                                      child: Text(
                                        AppLanguage
                                            .eventStatementtext[language],
                                        style: TextStyle(
                                          color:
                                              AppColor.secondryColor(context),
                                          fontFamily: AppFont.fontFamily,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 12.2,
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: size.height * 0.04),
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          PageTransition(
                                            type: PageTransitionType
                                                .rightToLeftWithFade,
                                            child: const splashMembers(),
                                            duration: const Duration(
                                                milliseconds: 500),
                                          ),
                                        );
                                      },
                                      child: Container(
                                        width: size.width * 0.86,
                                        height: size.height * 0.17,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          image: const DecorationImage(
                                            image: AssetImage(
                                                AppImage.memberBanner),
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: size.height * 0.02),
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          PageTransition(
                                            type: PageTransitionType
                                                .rightToLeftWithFade,
                                            child: const MyVenue(),
                                            duration: const Duration(
                                                milliseconds: 500),
                                          ),
                                        );
                                      },
                                      child: Container(
                                        width: size.width * 0.86,
                                        height: size.height * 0.17,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          image: const DecorationImage(
                                            image: AssetImage(
                                                AppImage.venuesBanner),
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: size.height * 0.02),
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          PageTransition(
                                            type: PageTransitionType
                                                .rightToLeftWithFade,
                                            child: const MyEvents(),
                                            duration: const Duration(
                                                milliseconds: 500),
                                          ),
                                        );
                                      },
                                      child: Container(
                                        width: size.width * 0.86,
                                        height: size.height * 0.17,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          image: const DecorationImage(
                                            image: AssetImage(
                                                AppImage.eventsBanner),
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        });
      },
    ).then((_) {});
  }
}
