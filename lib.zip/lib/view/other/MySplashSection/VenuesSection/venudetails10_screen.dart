import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:night_life/utilities/app_button.dart';
import 'package:night_life/utilities/app_font.dart';
import 'package:night_life/utilities/app_header.dart';
import 'package:night_life/utilities/app_language.dart';
import 'package:night_life/view/other/MySplashSection/VenuesSection/venuedetails8_screen.dart';

import '../../../../utilities/app_color.dart';
import '../../../../utilities/app_constant.dart';
import '../../../../utilities/app_image.dart';

class CompletePayment extends StatefulWidget {
  const CompletePayment({super.key});

  @override
  State<CompletePayment> createState() => _CompletePaymentState();
}

class _CompletePaymentState extends State<CompletePayment> {
  final Map<String, String> terms = {
    'covercharge': '50',
    'discount': '-10',
    'taxes': 'Included',
    'total': '450',
  };

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(AppConstant.systemUiOverlayStyle);
    final size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        backgroundColor: AppColor.primaryColor,
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: Padding(
          padding: const EdgeInsets.only(bottom: 40),
          child: AppButton(
            text: '${AppLanguage.paySecurelyText[language]} ₹${'450'}',
            onPress: () {
               Navigator.push(context,
                  MaterialPageRoute(builder: (context) => BookEvent()));
            },
          ),
        ),
        body: SafeArea(
          child: Container(
            height: size.height * 100 / 100,
            width: size.width * 100 / 100,
            child: Column(
              children: [
                Container(
                  width: size.width * 90 / 100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Image.asset(
                            color: AppColor.secondryColor,
                            height: size.width * 5 / 100,
                            width: size.width * 5 / 100,
                            AppImage.backArrowIcon),
                      ),
                      Text(
                         AppLanguage.completeYourPaymentText[language],
                        style: TextStyle(
                            fontFamily: AppFont.fontFamily,
                            fontWeight: FontWeight.w700,
                            fontSize: 18,
                            color: AppColor.secondryColor),
                      ),
                      Container(
                        height: size.width * 5 / 100,
                        width: size.width * 5 / 100,
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: size.height * 3 / 100,
                ),
                Expanded(
                    flex: 1,
                    child: SingleChildScrollView(
                        child: Container(
                      width: size.width * 90 / 100,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: size.height * 2 / 100,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${'10'}%off',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor),
                                  ),
                                  Text(
                                    'Bass Drop Fridays',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                        color: AppColor.secondryColor),
                                  ),
                                  Text(
                                    '${'Sun ${'23'}${' Jun'} · ${'2'} guests'}',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor),
                                  ),
                                ],
                              ),
                              Image.asset(
                                  height: size.height * 9 / 100,
                                  width: size.width * 40 / 100,
                                  AppImage.eventimg),
                            ],
                          ),
                          SizedBox(
                            height: size.height * 4 / 100,
                          ),
                          Text(
                            AppLanguage.paymentMethodsText[language],
                            style: TextStyle(
                                fontFamily: AppFont.fontFamily,
                                fontWeight: FontWeight.w700,
                                fontSize: 18,
                                color: AppColor.secondryColor),
                          ),
                          SizedBox(
                            height: size.height * 4 / 100,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Image.asset(
                                      height: size.width * 6 / 100,
                                      width: size.width * 6/ 100,
                                      AppImage.rupeesIcon),
                                  SizedBox(
                                    width: size.width * 6 / 100,
                                  ),
                                  Text(
                                      AppLanguage.upiText[language],
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: AppColor.secondryColor),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: size.height * 4 / 100,
                              ),
                              Row(
                                children: [
                                  Image.asset(
                                      height: size.width * 6 / 100,
                                      width: size.width * 6 / 100,
                                      AppImage.debitCardIcon),
                                  SizedBox(
                                    width: size.width * 6 / 100,
                                  ),
                                  Text(
                                      AppLanguage.debitCreditText[language],
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: AppColor.secondryColor),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: size.height * 4 / 100,
                              ),
                              Row(
                                children: [
                                  Image.asset(
                                      height: size.width * 6 / 100,
                                      width: size.width * 6 / 100,
                                      AppImage.walletIcon),
                                  SizedBox(
                                    width: size.width * 6 / 100,
                                  ),
                                  Text(
                                      AppLanguage.walletAppPayText[language],
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: AppColor.secondryColor),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            height: size.height * 4 / 100,
                          ),
                          Text(
                             AppLanguage.priceBreakdownText[language],
                            style: TextStyle(
                                fontFamily: AppFont.fontFamily,
                                fontWeight: FontWeight.w700,
                                fontSize: 18,
                                color: AppColor.secondryColor),
                          ),
                          SizedBox(
                            height: size.height * 2 / 100,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Divider(
                                thickness: 0.3,
                                color: AppColor.secondryColor,
                              ),
                              SizedBox(
                                height: size.height * 2 / 100,
                              ),
                              Container(
                                width: size.width * 60 / 100,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                       AppLanguage.coverChargeText[language],
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor,
                                      ),
                                    ),
                                    Text(
                                      '₹${terms['covercharge']}',
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: AppColor.secondryColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: size.height * 2 / 100,
                              ),
                              Divider(
                                thickness: 0.2,
                                color: AppColor.secondryColor,
                              ),
                              SizedBox(
                                height: size.height * 2 / 100,
                              ),
                              Container(
                                width: size.width * 60 / 100,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                     AppLanguage.discountText[language],
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor,
                                      ),
                                    ),
                                    Text(
                                      '${terms['discount']!}%',
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: AppColor.secondryColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: size.height * 2 / 100,
                              ),
                              Divider(
                                thickness: 0.2,
                                color: AppColor.secondryColor,
                              ),
                              SizedBox(
                                height: size.height * 2 / 100,
                              ),
                              Container(
                                width: size.width * 60 / 100,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      AppLanguage.taxesText[language],
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor,
                                      ),
                                    ),
                                    Text(
                                      '${terms['taxes']!}',
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: AppColor.secondryColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: size.height * 7 / 100,
                              ),
                              Container(
                                width: size.width * 60 / 100,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                        AppLanguage.totalText[language],
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor,
                                      ),
                                    ),
                                    Text(
                                      '₹${terms['total']!}',
                                      style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: AppColor.secondryColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: size.height * 20 / 100,
                          ),
                        ],
                      ),
                    )))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
