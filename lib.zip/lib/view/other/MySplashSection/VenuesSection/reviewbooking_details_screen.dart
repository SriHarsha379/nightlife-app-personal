import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:night_life/utilities/app_button.dart';
import 'package:night_life/utilities/app_font.dart';
import 'package:night_life/utilities/app_header.dart';
import 'package:night_life/utilities/app_language.dart';

import '../../../../utilities/app_color.dart';
import '../../../../utilities/app_constant.dart';
import '../../../../utilities/app_image.dart';
import 'venudetails10_screen.dart';

class ReviewBookingDetails extends StatefulWidget {
  ReviewBookingDetails({super.key});

  @override
  State<ReviewBookingDetails> createState() => _ReviewBookingDetailsState();
}

bool isOpen = false;

class _ReviewBookingDetailsState extends State<ReviewBookingDetails> {
  List<Map<String, String>> termsList = [
    {
      'id': '1',
      'text': 'Arrive 15 minutes early.',
    },
    {
      'id': '2',
      'text': 'Valid for the selected number of guests.',
    },
    {
      'id': '3',
      'text': 'Cover charges apply as per restaurant discretion.',
    },
    {
      'id': '4',
      'text': 'Offers valid only via app payment.',
    },
    {
      'id': '5',
      'text': 'Cover charges non-refundable if cancelled late.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(AppConstant.systemUiOverlayStyle);
    final size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        backgroundColor: AppColor.primaryColor,
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: Padding(
          padding: const EdgeInsets.only(bottom: 40),
          child: AppButton(
            text: AppLanguage.continueText[language],
            onPress: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => CompletePayment()));
            },
          ),
        ),
        body: SafeArea(
          child: Container(
            height: size.height * 100 / 100,
            width: size.width * 100 / 100,
            child: Column(
              children: [
                Container(
                  width: size.width * 90 / 100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Image.asset(
                            color: AppColor.secondryColor,
                            height: size.width * 5 / 100,
                            width: size.width * 5 / 100,
                            AppImage.backArrowIcon),
                      ),
                      Text(
                        AppLanguage.reviewBookingDetailsText[language],
                        style: TextStyle(
                            fontFamily: AppFont.fontFamily,
                            fontWeight: FontWeight.w700,
                            fontSize: 18,
                            color: AppColor.secondryColor),
                      ),
                      Container(
                        height: size.width * 5 / 100,
                        width: size.width * 5 / 100,
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: size.height * 2 / 100,
                ),
                Expanded(
                    flex: 1,
                    child: SingleChildScrollView(
                        child: Container(
                      width: size.width * 90 / 100,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: size.height * 2 / 100,
                          ),
                          Row(
                            children: [
                              Image.asset(
                                  height: size.width * 6 / 100,
                                  width: size.width * 6 / 100,
                                  AppImage.infoIcon),
                              SizedBox(
                                width: size.width * 5 / 100,
                              ),
                              Expanded(
                                child: ExpandableText(
                                  text: AppLanguage.noteMsgText[language],
                                  style: TextStyle(
                                    fontFamily: AppFont.fontFamily,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 16,
                                    color: AppColor.secondryColor,
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            height: size.height * 5 / 100,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${'24${' Oct at'}${'9:00 PM'} · ${'2 guests'}'}',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor),
                                  ),
                                  Text(
                                    'Bass Drop Fridays',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                        color: AppColor.secondryColor),
                                  ),
                                  Text(
                                    'Santacruz East, Mumbai',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor),
                                  ),
                                ],
                              ),
                              Image.asset(
                                  height: size.height * 9 / 100,
                                  width: size.width * 40 / 100,
                                  AppImage.eventimg),
                            ],
                          ),
                          SizedBox(
                            height: size.height * 4 / 100,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                AppLanguage.addSpecialRequestText[language],
                                style: TextStyle(
                                    fontFamily: AppFont.fontFamily,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 16,
                                    color: AppColor.secondryColor),
                              ),
                              GestureDetector(
                                onTap: () {},
                                child: Text(
                                  AppLanguage.plusText[language],
                                  style: TextStyle(
                                      fontFamily: AppFont.fontFamily,
                                      fontWeight: FontWeight.w300,
                                      fontSize: 30,
                                      color: AppColor.secondryColor),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: size.height * 4 / 100,
                          ),
                          Text(
                            AppLanguage.yourDetailsText[language],
                            style: TextStyle(
                                fontFamily: AppFont.fontFamily,
                                fontWeight: FontWeight.w700,
                                fontSize: 18,
                                color: AppColor.secondryColor),
                          ),
                          SizedBox(
                            height: size.height * 4 / 100,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                children: [
                                  Text(
                                    'Ethan Carter',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16,
                                        color: AppColor.secondryColor),
                                  ),
                                  Text(
                                    '+91 9876543210',
                                    style: TextStyle(
                                        fontFamily: AppFont.fontFamily,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: AppColor.pinkColor),
                                  ),
                                ],
                              ),
                              GestureDetector(
                                onTap: () {},
                                child: Text(
                                  AppLanguage.editText[language],
                                  style: TextStyle(
                                      fontFamily: AppFont.fontFamily,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16,
                                      color: AppColor.secondryColor),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: size.height * 4 / 100,
                          ),
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                isOpen = !isOpen;
                              });
                            },
                            child: Row(
                              children: [
                                // Text(
                                //   AppLanguage.termAndconditionsText[language],
                                //   style: TextStyle(
                                //     fontFamily: AppFont.fontFamily,
                                //     fontWeight: FontWeight.w700,
                                //     fontSize: 18,
                                //     color: AppColor.secondryColor,
                                //   ),
                                // ),
                                SizedBox(width: 8),
                                Transform.rotate(
                                  angle: isOpen ? 3.14 : 0,
                                  child: Image.asset(
                                    AppImage.downArrowicon,
                                    width: size.width * 5 / 100,
                                    height: size.width * 5 / 100,
                                    color: AppColor.secondryColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: size.height * 2 / 100,
                          ),
                         if (isOpen)
  ListView.builder(
    shrinkWrap: true,
    physics: NeverScrollableScrollPhysics(),
    itemCount: termsList.length,
    itemBuilder: (context, index) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 15),
        child: Text(
          termsList[index]['text']!,
          style: TextStyle(
            fontFamily: AppFont.fontFamily,
            fontWeight: FontWeight.w400,
            fontSize: 16,
            color: AppColor.secondryColor,
          ),
        ),
      );
    },
  ),

                          SizedBox(
                            height: size.height * 15 / 100,
                          ),
                        ],
                      ),
                    )))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ExpandableText extends StatefulWidget {
  final String text;
  final TextStyle style;

  const ExpandableText({
    super.key,
    required this.text,
    required this.style,
  });

  @override
  State<ExpandableText> createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<ExpandableText> {
  bool isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isExpanded = !isExpanded;
        });
      },
      child: AnimatedSize(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        child: ConstrainedBox(
          constraints: isExpanded
              ? const BoxConstraints()
              : const BoxConstraints(maxHeight: 25), // about 1 line height
          child: Text(
            widget.text,
            style: widget.style,
            overflow: isExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
            softWrap: true,
          ),
        ),
      ),
    );
  }
}
