﻿import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../../../provider/socket_provider.dart';
import '../../../../provider/user_chat_socket_provider.dart';
import '../../../../provider/user_controller.dart';
import '../../../../utilities/app_color.dart';
import '../../../../utilities/app_config_provider.dart';
import '../../../../utilities/app_constant.dart';
import '../../../../utilities/app_font.dart';
import '../../../../utilities/app_image.dart';
import '../../../../utilities/app_language.dart';
import '../MySplashSection/MembersSection/member_liked_details.dart';

class ChatMessageScreen extends StatefulWidget {
  static String routeName = "./ChatMessageScreen";
  final String name;
  final dynamic image;
  final String? receiverId;
  final String? conversationId;

  const ChatMessageScreen({
    super.key,
    required this.name,
    required this.image,
    this.receiverId,
    this.conversationId,
  });

  @override
  State<ChatMessageScreen> createState() => _ChatMessageScreenState();
}

class _ChatMessageScreenState extends State<ChatMessageScreen>
    with SingleTickerProviderStateMixin {
  bool isBottomSheetOpen = false; // Add this variable at the top of your State
  TextEditingController messageTextEditingController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  UserChatSocketProvider? _socketProvider;
  SocketProvider? _supportSocketProvider;
  UserController? _userController;
  bool _isBootstrapping = true;
  bool _joined = false;
  bool _conversationRequested = false;
  bool _historyRequestInFlight = false;
  int _conversationRequestAttempt = 0;
  int _lastVisibleMessageCount = 0;
  bool _didInitialScroll = false;
  String _userId = '';
  String _userName = '';
  String _userImage = '';
  String _receiverId = '';
  String _receiverName = '';
  String _receiverImage = '';
  String _conversationId = '';
  List messageList = [
    // {"id": 1, "message": "Hi", "time": "9:30 PM"},
    {"id": 2, "message": "Hey! New event this weekend", "time": "10:32 AM"},
    {"id": 2, "message": "Live band at Royal Venue 🎸", "time": "10:32 AM"},
    {"id": 3, "message": "Tickets going fast 👀", "time ": "5:05 PM"},
    {"id": 4, "message": "Oh nice! Didn’t know 😍", "time": "9:38 AM"},
    {"id": 5, "message": "Checking now.", "time": "9:38 AM"},
  ];
  bool isContainerVisible = false;
  bool isApproved = false;

  late AnimationController _controller;
  late Animation<Offset> _offsetAnimation;

  @override
  void initState() {
    super.initState();
    _receiverId = widget.receiverId?.trim() ?? '';
    _conversationId = widget.conversationId?.trim() ?? '';
    _receiverName = widget.name.trim();
    _receiverImage = _raw(widget.image);
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _offsetAnimation = Tween<Offset>(
      begin: const Offset(0, 1.0), // Bottom start
      end: Offset.zero, // Final position
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutBack,
    ));

    _controller.forward();
    _scrollController.addListener(_onChatScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _socketProvider =
          Provider.of<UserChatSocketProvider>(context, listen: false);
      _supportSocketProvider = Provider.of<SocketProvider>(context, listen: false);
      _userController = Provider.of<UserController>(context, listen: false);
      _socketProvider?.addListener(_handleSocketStateChanged);
      _bootstrapChat();
    });
  }

  @override
  void dispose() {
    _socketProvider?.removeListener(_handleSocketStateChanged);
    if (_socketProvider != null &&
        _joined &&
        _userId.isNotEmpty &&
        _conversationId.isNotEmpty) {
      _socketProvider!.leaveConversationChat(
        userId: _userId,
        conversationId: _conversationId,
      );
    }
    _socketProvider?.disconnect();
    _scrollController.removeListener(_onChatScroll);
    _scrollController.dispose();
    messageTextEditingController.dispose();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _bootstrapChat() async {
    await _loadUserFromController();
    if (!mounted) return;

    _supportSocketProvider?.disconnect();

    await _socketProvider?.initSocket(AppConstant.token);
    if (_userId.isNotEmpty) {
      _requestConversationList();
      _joinConversationIfReady();
      if (_receiverId.isNotEmpty) {
        _socketProvider?.emitUserStatus(
          userId: _userId,
          checkUserId: _receiverId,
        );
      }
    }

    if (!mounted) return;
    setState(() {
      _isBootstrapping = false;
    });
  }

  Future<void> _loadUserFromController() async {
    if (_userController == null) return;
    await _userController!.getUserDetails();
    _userId = _userController!.getUserId.trim();
    _userName = _userController!.getUserName.trim().isEmpty
        ? 'User'
        : _userController!.getUserName.trim();
    _userImage = _userController!.getUserImage.trim();
  }

  void _requestConversationList() {
    if (!mounted || _socketProvider == null || _userId.isEmpty) return;
    if (_conversationRequested) return;
    if (_socketProvider!.isConnected) {
      _conversationRequested = _socketProvider!
          .getConversationList(userId: _userId, page: 1, limit: 50);
      return;
    }
    _conversationRequestAttempt += 1;
    if (_conversationRequestAttempt <= 40) {
      Future.delayed(
          const Duration(milliseconds: 500), _requestConversationList);
    }
  }

  void _handleSocketStateChanged() {
    if (!mounted || _socketProvider == null) return;
    if (!_socketProvider!.isConnected) {
      _conversationRequested = false;
      _joined = false;
    }
    final previousConversationId = _conversationId;
    _requestConversationList();

    final item = _resolveUserConversation(_socketProvider!.conversationList);
    if (item != null) {
      final resolvedConversationId = _extractConversationId(item);
      if (resolvedConversationId.isNotEmpty &&
          (_conversationId.isEmpty ||
              !_conversationExistsInList(_conversationId))) {
        _conversationId = resolvedConversationId;
      }

      final resolvedUserId = _extractOtherUserId(item);
      if (_receiverId.isEmpty && resolvedUserId.isNotEmpty) {
        _receiverId = resolvedUserId;
      }
    }

    if (previousConversationId != _conversationId) {
      _joined = false;
    }

    if (_socketProvider!.isConnected &&
        _userId.isNotEmpty &&
        _receiverId.isNotEmpty) {
      _socketProvider!.emitUserStatus(
        userId: _userId,
        checkUserId: _receiverId,
      );
    }

    _joinConversationIfReady();
  }

  Map<String, dynamic>? _resolveUserConversation(
      List<Map<String, dynamic>> list) {
    if (list.isEmpty) return null;

    if (_conversationId.isNotEmpty) {
      for (final item in list) {
        if (_extractConversationId(item) == _conversationId) return item;
      }
    }

    if (_receiverId.isNotEmpty) {
      for (final item in list) {
        if (_extractOtherUserId(item) == _receiverId) return item;
      }
    }

    final targetName = _receiverName.toLowerCase().trim();
    if (targetName.isNotEmpty) {
      for (final item in list) {
        if (_extractOtherUserName(item).toLowerCase().trim() == targetName) {
          return item;
        }
      }
    }

    if (_receiverId.isEmpty && _receiverName.isEmpty) {
      return list.first;
    }
    return null;
  }

  bool _conversationExistsInList(String conversationId) {
    if (_socketProvider == null || conversationId.trim().isEmpty) return false;
    for (final item in _socketProvider!.conversationList) {
      if (_extractConversationId(item) == conversationId) return true;
    }
    return false;
  }

  String _extractConversationId(Map<String, dynamic> item) {
    return (item['_id'] ?? item['conversation_id'] ?? '').toString().trim();
  }

  String _extractId(dynamic raw) {
    if (raw == null) return '';
    if (raw is Map) {
      return (raw['_id'] ?? raw['user_id'] ?? raw['id'] ?? '')
          .toString()
          .trim();
    }
    return raw.toString().trim();
  }

  String _extractOtherUserId(Map<String, dynamic> item) {
    final senderId = _extractId(item['sender_id']);
    final receiverId = _extractId(item['receiver_id']);
    if (senderId == _userId) return receiverId;
    if (receiverId == _userId) return senderId;
    if (_receiverId.isNotEmpty && senderId == _receiverId) return senderId;
    if (_receiverId.isNotEmpty && receiverId == _receiverId) return receiverId;
    return receiverId;
  }

  String _extractOtherUserName(Map<String, dynamic> item) {
    final sender = item['sender_id'];
    final receiver = item['receiver_id'];
    final senderId = _extractId(sender);
    final receiverId = _extractId(receiver);

    if (sender is Map && senderId != _userId) {
      return (sender['name'] ?? sender['full_name'] ?? '').toString().trim();
    }
    if (receiver is Map && receiverId != _userId) {
      return (receiver['name'] ?? receiver['full_name'] ?? '')
          .toString()
          .trim();
    }
    return '';
  }

  void _joinConversationIfReady() {
    if (!mounted || _socketProvider == null) return;
    if (_joined) return;
    if (_userId.isEmpty || _conversationId.isEmpty) return;
    if (!_socketProvider!.isConnected) return;

    _socketProvider!.joinConversationChat(
      userId: _userId,
      conversationId: _conversationId,
      firstPageLimit: 50,
    );
    _joined = true;
  }

  bool _belongsToCurrentConversation(Map<String, dynamic> message) {
    final msgConversationId =
        (message['conversation_id'] ?? message['conversationId'] ?? '')
            .toString()
            .trim();
    if (_conversationId.isNotEmpty && msgConversationId.isNotEmpty) {
      return msgConversationId == _conversationId;
    }

    final sender = _extractId(message['sender_id'] ?? message['senderId']);
    final receiver =
        _extractId(message['receiver_id'] ?? message['receiverId']);
    if (_receiverId.isEmpty || _userId.isEmpty) return false;
    return (sender == _userId && receiver == _receiverId) ||
        (sender == _receiverId && receiver == _userId);
  }

  bool _isMine(Map<String, dynamic> message) {
    return _extractId(message['sender_id'] ?? message['senderId']) == _userId;
  }

  void _onChatScroll() {
    if (!mounted || _socketProvider == null) return;
    if (!_joined || _conversationId.isEmpty || _userId.isEmpty) return;
    if (!_scrollController.hasClients) return;

    if (_scrollController.position.pixels > 120) return;
    if (_historyRequestInFlight || _socketProvider!.isLoadingMore) return;

    _historyRequestInFlight = true;
    _socketProvider!.loadMoreConversationMessages(
      userId: _userId,
      conversationId: _conversationId,
      limit: 50,
    );
    Future.delayed(const Duration(milliseconds: 700), () {
      _historyRequestInFlight = false;
    });
  }

  void _maybeAutoScroll(int messageCount) {
    if (messageCount <= 0 || messageCount == _lastVisibleMessageCount) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scrollController.hasClients) return;
      final target = _scrollController.position.maxScrollExtent;
      if (!_didInitialScroll) {
        _scrollController.jumpTo(target);
        _didInitialScroll = true;
      } else {
        _scrollController.animateTo(
          target,
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
        );
      }
      _lastVisibleMessageCount = messageCount;
    });
  }

  void _sendMessage() {
    final text = messageTextEditingController.text.trim();
    if (text.isEmpty) return;
    if (_userId.isEmpty || _receiverId.isEmpty || _conversationId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chat is loading. Please wait.')),
      );
      return;
    }

    Provider.of<UserChatSocketProvider>(context, listen: false)
        .sendConversationMessage(
      senderId: _userId,
      senderName: _userName,
      senderImage: _userImage,
      receiverId: _receiverId,
      receiverName: _receiverName,
      receiverImage: (_receiverImage.startsWith('assets/') ||
              _receiverImage.startsWith('./assets/'))
          ? ''
          : _receiverImage,
      conversationId: _conversationId,
      message: text,
      senderModel: 'User',
      receiverModel: 'User',
    );

    messageTextEditingController.clear();
    FocusScope.of(context).unfocus();
  }

  String _raw(dynamic value) => (value ?? '').toString().trim();

  ImageProvider _chatAvatar(dynamic value) {
    final raw = _raw(value);
    if (raw.isEmpty || raw == 'null') {
      return const AssetImage(AppImage.placeHolder2Icon);
    }
    final normalized = raw.replaceFirst(RegExp(r'^\./'), '');
    if (normalized.startsWith('assets/')) {
      return AssetImage(normalized);
    }
    if (normalized.startsWith('http://') || normalized.startsWith('https://')) {
      return NetworkImage(normalized);
    }
    return NetworkImage('${AppConfigProvider.imageUrl}$normalized');
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        systemNavigationBarColor: AppColor.primaryColor(context),
        systemNavigationBarIconBrightness: Brightness.light,
        statusBarColor: AppColor.primaryColor(context),
        statusBarIconBrightness: Brightness.light));
    final size = MediaQuery.of(context).size;

    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
          setState(() {
            isContainerVisible = false;
          });
        },
        child: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0),
            child: AppBar(
              // backgroundColor: AppColor.backgroundColor,
              systemOverlayStyle: SystemUiOverlayStyle(
                systemNavigationBarColor: Color(0xff000000),
                systemNavigationBarIconBrightness: Brightness.light,
                statusBarColor: Color(0xff000000),
                statusBarIconBrightness: Brightness.light,
              ),
            ),
          ),
          body: SafeArea(
              child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 100 / 100,
                height: MediaQuery.of(context).size.height * 100 / 100,
                color: AppColor.primaryColor(context),
                child: Column(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 100 / 100,
                      height: MediaQuery.of(context).size.height * 9 / 100,
                      alignment: Alignment.center,
                      //  color: AppColor.themeColor,
                      child: Row(
                        //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Container(
                              height:
                                  MediaQuery.of(context).size.width * 10 / 100,
                              width:
                                  MediaQuery.of(context).size.width * 12 / 100,
                              color: AppColor.transparentColor,
                              //  padding: const EdgeInsets.only(left: 13),
                              alignment: Alignment.center,
                              child: Image.asset(
                                AppImage.backArrowIcon,
                                fit: BoxFit.cover,
                                height:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                width:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                color: AppColor.secondryColor(context),
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                PageTransition(
                                  type: PageTransitionType.rightToLeftWithFade,
                                  child: const LikedMemberDetail(),
                                  duration: const Duration(milliseconds: 500),
                                ),
                              );
                            },
                            child: SizedBox(
                              width:
                                  MediaQuery.of(context).size.width * 60 / 100,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                      width: MediaQuery.of(context).size.width *
                                          10 /
                                          100,
                                      height:
                                          MediaQuery.of(context).size.width *
                                              10 /
                                              100,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          // border: Border.all(
                                          //     color: AppColor.secondaryColor,
                                          //     width: 1),
                                          image: DecorationImage(
                                            image: _chatAvatar(widget.image),
                                            fit: BoxFit.cover,
                                          ))),
                                  SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          2 /
                                          100),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                45 /
                                                100,
                                        child: Row(
                                          children: [
                                            Text(widget.name,
                                                style: TextStyle(
                                                    color:
                                                        AppColor.secondryColor(
                                                            context),
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        AppFont.fontFamily)),
                                          ],
                                        ),
                                      ),
                                      Consumer<UserChatSocketProvider>(
                                        builder: (context, socketProvider, _) {
                                          final isThisUserStatus = _receiverId
                                                  .isNotEmpty &&
                                              socketProvider.checkedUserId ==
                                                  _receiverId;
                                          final isOnline =
                                              isThisUserStatus &&
                                                  (socketProvider
                                                          .isCheckedUserOnline ==
                                                      true);
                                          final statusText = isOnline
                                              ? 'Online'
                                              : AppLanguage
                                                  .activeTwominuteAgotext[
                                                      language];
                                          return Text(
                                            statusText,
                                            style: TextStyle(
                                              height: 1,
                                              color: isOnline
                                                  ? Colors.green
                                                  : AppColor.textcolor,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: AppFont.fontFamily,
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          // SizedBox(
                          //     width:
                          //         MediaQuery.of(context).size.width * 1 / 100),
                          // Container(
                          //   height: size.height * 4.5 / 100,
                          //   width: size.width * 4.5 / 100,
                          //   child: Image.asset(
                          //     AppImage.callIcon,
                          //     color: AppColor.secondryColor(context),
                          //   ),
                          // ),
                          // SizedBox(
                          //     width:
                          //         MediaQuery.of(context).size.width * 3 / 100),
                          // Container(
                          //   height: size.height * 6 / 100,
                          //   width: size.width * 5 / 100,
                          //   child: Image.asset(
                          //     AppImage.vedioCallicon,
                          //     color: AppColor.secondryColor(context),
                          //   ),
                          // ),
                          SizedBox(
                              width:
                                  MediaQuery.of(context).size.width * 15 / 100),
                          GestureDetector(
                            onTap: () {
                              reportBottomSheet(context);
                            },
                            child: Image.asset(
                              AppImage.threedotIcon,
                              color: AppColor.secondryColor(context),
                            ),
                          ),
                          SizedBox(
                              width: MediaQuery.of(context).size.width *
                                  0.5 /
                                  100),
                        ],
                      ),
                    ),
                    Expanded(
                        flex: 1,
                        child: SingleChildScrollView(
                          controller: _scrollController,
                          reverse: true,
                          child: Column(
                            children: [
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      1 /
                                      100),
                              _isBootstrapping
                                  ? const Padding(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 20),
                                      child: CircularProgressIndicator(
                                        color: AppColor.buttonColor,
                                      ),
                                    )
                                  : Consumer<UserChatSocketProvider>(
                                      builder: (context, socketProvider, _) {
                                        final visibleMessages = socketProvider
                                            .messages
                                            .where(
                                                _belongsToCurrentConversation)
                                            .toList();
                                        _maybeAutoScroll(
                                            visibleMessages.length);

                                        if (visibleMessages.isEmpty) {
                                          return const SizedBox.shrink();
                                        }

                                        return Wrap(
                                          runSpacing: 2.0,
                                          children: List.generate(
                                              visibleMessages.length, (index) {
                                            final message =
                                                visibleMessages[index];
                                            final mine = _isMine(message);
                                            final text =
                                                (message['message'] ?? '')
                                                    .toString();
                                            if (text.trim().isEmpty) {
                                              return const SizedBox.shrink();
                                            }
                                            return SizedBox(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  92 /
                                                  100,
                                              child: Column(
                                                crossAxisAlignment: !mine
                                                    ? CrossAxisAlignment.start
                                                    : CrossAxisAlignment.end,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment: !mine
                                                        ? MainAxisAlignment
                                                            .start
                                                        : MainAxisAlignment.end,
                                                    children: [
                                                      if (!mine)
                                                        GestureDetector(
                                                          onTap: () {
                                                            Navigator.push(
                                                              context,
                                                              PageTransition(
                                                                type: PageTransitionType
                                                                    .rightToLeftWithFade,
                                                                child:
                                                                    const LikedMemberDetail(),
                                                                duration:
                                                                    const Duration(
                                                                        milliseconds:
                                                                            500),
                                                              ),
                                                            );
                                                          },
                                                          child: Container(
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width *
                                                                10 /
                                                                100,
                                                            height: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width *
                                                                10 /
                                                                100,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          100),
                                                              image:
                                                                  DecorationImage(
                                                                image: _chatAvatar(
                                                                    widget
                                                                        .image),
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      if (!mine)
                                                        SizedBox(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width *
                                                              2 /
                                                              100,
                                                        ),
                                                      Container(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                          vertical: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .height *
                                                              2 /
                                                              100,
                                                          horizontal:
                                                              MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  3 /
                                                                  100,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: !mine
                                                              ? AppColor
                                                                  .washpressColor
                                                              : AppColor
                                                                  .buttonColor,
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: Colors
                                                                  .black
                                                                  .withOpacity(
                                                                      0.2),
                                                              blurRadius: 10,
                                                              offset:
                                                                  const Offset(
                                                                      0, 4),
                                                            ),
                                                          ],
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            topLeft: mine
                                                                ? const Radius
                                                                    .circular(
                                                                    25)
                                                                : const Radius
                                                                    .circular(
                                                                    0),
                                                            topRight: mine
                                                                ? const Radius
                                                                    .circular(0)
                                                                : const Radius
                                                                    .circular(
                                                                    25),
                                                            bottomLeft:
                                                                const Radius
                                                                    .circular(
                                                                    25),
                                                            bottomRight:
                                                                const Radius
                                                                    .circular(
                                                                    25),
                                                          ),
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            SizedBox(
                                                              child: Text(
                                                                text,
                                                                style:
                                                                    TextStyle(
                                                                  color: AppColor
                                                                      .secondryColor(
                                                                          context),
                                                                  fontSize: 14,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  fontFamily:
                                                                      AppFont
                                                                          .fontFamily,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            );
                                          }),
                                        );
                                      },
                                    ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      4 /
                                      100),
                              SlideTransition(
                                position: _offsetAnimation,
                                child: Stack(
                                  children: [
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          90 /
                                          100,
                                      child: Align(
                                        alignment: Alignment.centerRight,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(16),
                                          child: Image.asset(
                                            AppImage.msgCardicon,
                                            fit: BoxFit.cover,
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.70,
                                            height: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                0.40,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      left: size.width * 24 / 100,
                                      right: 0,
                                      bottom: size.height * 2 / 100,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Bass Drop Fridays",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 18,
                                            ),
                                          ),
                                          SizedBox(height: 6),
                                          Row(
                                            children: [
                                              Icon(Icons.schedule,
                                                  color: AppColor.buttonColor,
                                                  size: 16),
                                              SizedBox(width: 6),
                                              Text(
                                                "Fri, 10 PM – 4 AM",
                                                style: TextStyle(
                                                    color: AppColor.buttonColor,
                                                    fontSize: 14),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 4),
                                          Row(
                                            children: [
                                              Icon(Icons.location_on,
                                                  color: Colors.white,
                                                  size: 16),
                                              SizedBox(width: 6),
                                              Text(
                                                "Club Neon, Downtown • 2.3 km",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 14),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width:
                                    MediaQuery.of(context).size.width * 5 / 100,
                              ),
                              SizedBox(
                                height: MediaQuery.of(context).size.height *
                                    1 /
                                    100,
                              ),
                              SlideTransition(
                                position: _offsetAnimation,
                                child: Column(
                                  children: [
                                    // Accept Button
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          90 /
                                          100,
                                      child: Align(
                                        alignment: Alignment.centerRight,
                                        child: GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              isApproved = true;
                                            });
                                          },
                                          child: Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.70,
                                            height: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                0.06,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                              color: isApproved
                                                  ? AppColor.greenColor1
                                                  : AppColor.statusbar,
                                            ),
                                            child: Center(
                                              child: Text(
                                                isApproved
                                                    ? "Approved"
                                                    : "Accept",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),

                                    SizedBox(height: 15),

                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          90 /
                                          100,
                                      child: Align(
                                        alignment: Alignment.centerRight,
                                        child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.70,
                                          height: MediaQuery.of(context)
                                                  .size
                                                  .height *
                                              0.06,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(50),
                                            color: Colors.grey.shade900,
                                          ),
                                          child: Center(
                                            child: Text(
                                              'Reject',
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        )),
                    AnimatedPadding(
                      duration: const Duration(milliseconds: 180),
                      curve: Curves.easeOut,
                      padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom,
                      ),
                      child: Column(
                        children: [
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 4 / 100,
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 90 / 100,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.2),
                                        blurRadius: 10,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width * 90 / 100,
                                    height:
                                        MediaQuery.of(context).size.height * 7 / 100,
                                    child: TextFormField(
                                      cursorColor: AppColor.secondryColor(context),
                                      style: TextStyle(
                                        height: 1,
                                        color: AppColor.secondryColor(context),
                                      ),
                                      textAlignVertical: TextAlignVertical.center,
                                      keyboardType: TextInputType.name,
                                      maxLength: AppConstant.describeLength,
                                      controller: messageTextEditingController,
                                      onFieldSubmitted: (_) => _sendMessage(),
                                      decoration: InputDecoration(
                                        isDense: true,
                                        suffixIconConstraints: BoxConstraints(
                                          maxWidth:
                                              MediaQuery.of(context).size.width *
                                                  30 /
                                                  100,
                                        ),
                                        prefixIcon: Padding(
                                          padding:
                                              const EdgeInsets.only(right: 9.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 8.0),
                                                child: Container(
                                                  height: MediaQuery.of(context)
                                                          .size
                                                          .height *
                                                      0.04,
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .height *
                                                      0.04,
                                                  decoration: BoxDecoration(
                                                    color: AppColor.buttonColor,
                                                    shape: BoxShape.circle,
                                                  ),
                                                  child: Center(
                                                    child: Image.asset(
                                                      AppImage.cameraIcon,
                                                      fit: BoxFit.contain,
                                                      height:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .height *
                                                              0.026,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        suffixIcon: Padding(
                                          padding: const EdgeInsets.only(left: 4),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              GestureDetector(
                                                onTap: _sendMessage,
                                                child: Image.asset(
                                                  AppImage.shareImg,
                                                  height: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      6 /
                                                      100,
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      6 /
                                                      100,
                                                  color: AppColor
                                                      .secondryColor(context)
                                                      .withOpacity(0.5),
                                                ),
                                              ),
                                              SizedBox(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    1 /
                                                    100,
                                              ),
                                              Image.asset(
                                                AppImage.microphone,
                                                height: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    6 /
                                                    100,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    6 /
                                                    100,
                                                color: AppColor.secondryColor(
                                                        context)
                                                    .withOpacity(0.5),
                                              ),
                                              SizedBox(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    2 /
                                                    100,
                                              ),
                                              GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    isBottomSheetOpen =
                                                        !isBottomSheetOpen;
                                                  });
                                                  if (isBottomSheetOpen) {
                                                    plusiconsBottomSheet(context)
                                                        .whenComplete(() {
                                                      setState(() {
                                                        isBottomSheetOpen = false;
                                                      });
                                                    });
                                                  }
                                                },
                                                child: Image.asset(
                                                  AppImage.plusIcon,
                                                  height: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      6 /
                                                      100,
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      6 /
                                                      100,
                                                  color: AppColor
                                                      .secondryColor(context)
                                                      .withOpacity(0.5),
                                                ),
                                              ),
                                              SizedBox(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    3 /
                                                    100,
                                              ),
                                            ],
                                          ),
                                        ),
                                        border: const OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColor.washpressColor),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(40)),
                                        ),
                                        enabledBorder: const OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColor.washpressColor),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(40)),
                                        ),
                                        focusedBorder: const OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColor.washpressColor),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(40)),
                                        ),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                                vertical: 16, horizontal: 15),
                                        fillColor: AppColor.washpressColor,
                                        filled: true,
                                        counterText: '',
                                        hintText: AppLanguage.messageText[
                                            language],
                                        hintStyle: const TextStyle(
                                          color: AppColor.textcolor,
                                          fontFamily: AppFont.fontFamily,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 1 / 100,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ],
          )),
        ),
      ),
    );
  }

  Future<void> plusiconsBottomSheet(BuildContext context) {
    return showModalBottomSheet<void>(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(),
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setStateBottomSheet) {
          return Container(
            height: MediaQuery.of(context).size.height * 28 / 100,
            width: MediaQuery.of(context).size.width * 90 / 100,
            color: Colors.transparent,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                    width: MediaQuery.of(context).size.width * 32 / 100,
                    height: MediaQuery.of(context).size.height * 18 / 100,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: AppColor.washpressColor),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width:
                                  MediaQuery.of(context).size.width * 10 / 100,
                              child: Image.asset(
                                AppImage.vedioIcon,
                                width:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                height:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                color: AppColor.secondryColor(context),
                              ),
                            ),
                            SizedBox(
                              child: Text(
                                AppLanguage.videoText[language],
                                style: TextStyle(
                                  fontSize: 15,
                                  decoration: TextDecoration.none,
                                  color: AppColor.secondryColor(context),
                                  fontFamily: AppFont.fontFamily,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                            height:
                                MediaQuery.of(context).size.height * 1 / 100),
                        Row(
                          children: [
                            SizedBox(
                              width:
                                  MediaQuery.of(context).size.width * 10 / 100,
                              child: Image.asset(
                                AppImage.gifIcon,
                                width:
                                    MediaQuery.of(context).size.width * 4 / 100,
                                height:
                                    MediaQuery.of(context).size.width * 4 / 100,
                                color: AppColor.secondryColor(context),
                              ),
                            ),
                            SizedBox(
                              child: Text(
                                AppLanguage.gifText[language],
                                style: TextStyle(
                                  fontSize: 15,
                                  decoration: TextDecoration.none,
                                  color: AppColor.secondryColor(context),
                                  fontFamily: AppFont.fontFamily,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                            height:
                                MediaQuery.of(context).size.height * 1 / 100),
                        Row(
                          children: [
                            SizedBox(
                              width:
                                  MediaQuery.of(context).size.width * 10 / 100,
                              child: Image.asset(
                                AppImage.eventIcon,
                                width:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                height:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                color: AppColor.secondryColor(context),
                              ),
                            ),
                            SizedBox(
                              child: Text(
                                AppLanguage.eventsText[language],
                                style: TextStyle(
                                  fontSize: 15,
                                  decoration: TextDecoration.none,
                                  color: AppColor.secondryColor(context),
                                  fontFamily: AppFont.fontFamily,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                            height:
                                MediaQuery.of(context).size.height * 1 / 100),
                        Row(
                          children: [
                            SizedBox(
                              width:
                                  MediaQuery.of(context).size.width * 10 / 100,
                              child: Image.asset(
                                AppImage.locationBlackicon,
                                width:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                height:
                                    MediaQuery.of(context).size.width * 5 / 100,
                                color: AppColor.secondryColor(context),
                              ),
                            ),
                            SizedBox(
                              child: Text(
                                AppLanguage.locationText[language],
                                style: TextStyle(
                                  fontSize: 15,
                                  decoration: TextDecoration.none,
                                  color: AppColor.secondryColor(context),
                                  fontFamily: AppFont.fontFamily,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            )
                          ],
                        ),
                      ],
                    )),
              ],
            ),
          );
        });
      },
    );
  }

  Future<void> reportBottomSheet(BuildContext context) {
    return showModalBottomSheet<void>(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setStateBottomSheet) {
          return GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Container(
              color: Colors.transparent,
              child: Stack(
                children: [
                  Positioned(
                    top: MediaQuery.of(context).size.height * 10 / 100,
                    right: MediaQuery.of(context).size.width * 5 / 100,
                    child: GestureDetector(
                      onTap: () {},
                      child: Container(
                        width: MediaQuery.of(context).size.width * 40 / 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: AppColor.washpressColor,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 10,
                              spreadRadius: 2,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.symmetric(
                            vertical: 18, horizontal: 15),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            InkWell(
                              onTap: () {
                                // Handle Open Share date action
                                Navigator.pop(context);
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8.0, horizontal: 4.0),
                                child: Text(
                                  'Block User',
                                  style: TextStyle(
                                    fontSize: 15,
                                    decoration: TextDecoration.none,
                                    color: AppColor.secondryColor(context),
                                    fontFamily: AppFont.fontFamily,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height *
                                    0.5 /
                                    100),
                            InkWell(
                              onTap: () {
                                // Handle Report action
                                Navigator.pop(context);
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8.0, horizontal: 4.0),
                                child: Text(
                                  "Unmatch",
                                  style: TextStyle(
                                    fontSize: 15,
                                    decoration: TextDecoration.none,
                                    color: AppColor.secondryColor(context),
                                    fontFamily: AppFont.fontFamily,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height *
                                    0.5 /
                                    100),
                            InkWell(
                              onTap: () {
                                // Handle Unmatch action
                                Navigator.pop(context);
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8.0, horizontal: 4.0),
                                child: Text(
                                  "Report",
                                  style: TextStyle(
                                    fontSize: 15,
                                    decoration: TextDecoration.none,
                                    color: AppColor.secondryColor(context),
                                    fontFamily: AppFont.fontFamily,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height *
                                    0.5 /
                                    100),
                            // InkWell(
                            //   onTap: () {
                            //     // Handle Did you meet action
                            //     Navigator.pop(context);
                            //   },
                            //   child: Padding(
                            //     padding: const EdgeInsets.symmetric(
                            //         vertical: 8.0, horizontal: 4.0),
                            //   ),
                            // ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
      },
    );
  }
}
