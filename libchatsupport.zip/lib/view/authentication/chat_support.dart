import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:night_life/utilities/app_language.dart';
import 'dart:convert';
import '../../helper/ImagePreviewScreen.dart';
import '../../provider/socket_provider.dart';
import '../../provider/user_controller.dart';
import '../../utilities/app_color.dart';
import '../../utilities/app_constant.dart';
import '../../utilities/app_config_provider.dart';
import '../../utilities/app_font.dart';
import '../../utilities/app_header.dart';
import '../../utilities/app_image.dart';

class ChatSupport extends StatefulWidget {
  static String routeName = './ChatSupport';

  final String? supportUserId;
  final String? conversationId;
  final String supportName;
  final String supportImage;

  const ChatSupport({
    super.key,
    this.supportUserId,
    this.conversationId,
    this.supportName = 'Support',
    this.supportImage = '',
  });

  @override
  State<ChatSupport> createState() => _ChatSupportState();
}

class _ChatSupportState extends State<ChatSupport> {
  final TextEditingController messageTextEditingController =
      TextEditingController();
  final ScrollController _scrollController = ScrollController();

  String _userId = '';
  String _userName = '';
  String _userImage = '';

  String _supportUserId = '';
  String _supportName = '';
  String _supportImage = '';

  String _conversationId = '';
  bool _isBootstrapping = true;
  bool _joined = false;
  bool _conversationRequested = false;
  int _conversationRequestAttempt = 0;
  bool _conversationListReceived = false;
  int _lastVisibleMessageCount = 0;
  bool _didInitialScroll = false;
  bool _historyRequestInFlight = false;
  bool _isUploadingMedia = false;
  bool _conversationIdRefreshInFlight = false;

  SocketProvider? _socketProvider;
  UserController? _userController;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onChatScroll);
    _supportUserId = widget.supportUserId?.trim() ?? '';
    _conversationId = widget.conversationId?.trim() ?? '';
    _supportName =
        widget.supportName.trim().isEmpty ? 'Support' : widget.supportName;
    _supportImage = widget.supportImage;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _socketProvider = Provider.of<SocketProvider>(context, listen: false);
      _userController = Provider.of<UserController>(context, listen: false);
      _socketProvider?.addListener(_handleSocketStateChanged);
      _bootstrapChat();
    });
  }

  Future<void> _bootstrapChat() async {
    await _loadUserFromController();
    await _resolveAdminDetailsFromApi();
    debugPrint(
      'ChatSupport bootstrap => userId=$_userId userName=$_userName supportUserId=$_supportUserId conversationId=$_conversationId',
    );

    if (!mounted) return;

    final socketProvider = Provider.of<SocketProvider>(context, listen: false);
    await socketProvider.initSocket(AppConstant.token);

    if (_userId.isNotEmpty) {
      _requestConversationList();

      if (_conversationId.isNotEmpty) {
        _joinConversationIfReady();
      }

      if (_supportUserId.isNotEmpty) {
        final sent = socketProvider.emitUserStatus(
          userId: _userId,
          checkUserId: _supportUserId,
        );
        if (!sent) {
          debugPrint('ChatSupport user_status skipped: socket not ready');
        }
      }
    }

    if (!mounted) return;
    setState(() {
      _isBootstrapping = false;
    });
  }

  Future<void> _resolveAdminDetailsFromApi({
    bool allowConversationIdHydration = true,
  }) async {
    if (_userId.isEmpty) return;
    if (AppConstant.token.trim().isEmpty) return;

    try {
      final response = await http.get(
        Uri.parse('${AppConfigProvider.apiUrl}user/admin_details'),
        headers: {
          'authorization': 'Bearer ${AppConstant.token}',
        },
      );

      if (response.statusCode != 200) return;

      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) return;
      if (decoded['success'] != true) return;

      final payload = decoded['message'];
      if (payload is! Map) return;

      final admin = payload['admin'];
      if (admin is Map) {
        final adminId = (admin['_id'] ?? '').toString().trim();
        final adminName =
            (admin['name'] ?? admin['user_name'] ?? '').toString().trim();
        final adminImage = (admin['profile_image'] ?? '').toString().trim();

        if (adminId.isNotEmpty && _supportUserId.isEmpty) {
          _supportUserId = adminId;
        }
        if (adminName.isNotEmpty &&
            (_supportName.trim().isEmpty || _supportName == 'Support')) {
          _supportName = adminName;
        }
        if (adminImage.isNotEmpty && _supportImage.trim().isEmpty) {
          _supportImage = adminImage;
        }
      }

      if (allowConversationIdHydration && _conversationId.isEmpty) {
        final apiConversationId =
            (payload['conversation_id'] ?? '').toString().trim();
        if (apiConversationId.isNotEmpty) {
          _conversationId = apiConversationId;
          _joined = false;
          _joinConversationIfReady();
        }
      }
    } catch (e) {
      debugPrint('ChatSupport admin_details failed: $e');
    }
  }

  void _scheduleConversationIdRefresh() {
    if (_conversationId.isNotEmpty) return;
    if (_conversationIdRefreshInFlight) return;
    _conversationIdRefreshInFlight = true;
    Future.delayed(const Duration(milliseconds: 1500), () async {
      if (!mounted) {
        _conversationIdRefreshInFlight = false;
        return;
      }
      await _resolveAdminDetailsFromApi(allowConversationIdHydration: true);
      _conversationIdRefreshInFlight = false;
    });
  }

  void _requestConversationList() {
    if (!mounted || _socketProvider == null || _userId.isEmpty) return;
    if (_conversationRequested) return;
    if (_conversationListReceived) return;
    if (_socketProvider!.conversationList.isNotEmpty) {
      _conversationListReceived = true;
      _conversationRequested = true;
      return;
    }

    if (_socketProvider!.isConnected) {
      debugPrint(
          'ChatSupport get_conversation_list emit => userId=$_userId attempt=$_conversationRequestAttempt');
      final sent = _socketProvider!
          .getConversationList(userId: _userId, page: 1, limit: 50);
      if (sent) {
        _conversationRequested = true;
        _conversationRequestAttempt = 0;
      } else {
        debugPrint(
            'ChatSupport get_conversation_list skipped: socket not ready');
      }
      return;
    }

    _conversationRequestAttempt += 1;
    if (_conversationRequestAttempt <= 40) {
      debugPrint(
        'ChatSupport waiting for socket connect, retry get_conversation_list attempt=$_conversationRequestAttempt',
      );
      Future.delayed(
          const Duration(milliseconds: 500), _requestConversationList);
    } else {
      debugPrint(
          'ChatSupport failed to request conversation list after retries');
    }
  }

  void _onChatScroll() {
    if (!mounted || _socketProvider == null) return;
    if (!_joined || _conversationId.isEmpty || _userId.isEmpty) return;
    if (!_scrollController.hasClients) return;

    final position = _scrollController.position;
    if (position.pixels > 120) return;
    if (_historyRequestInFlight || _socketProvider!.isLoadingMore) return;

    _historyRequestInFlight = true;
    _socketProvider!.loadMoreConversationMessages(
      userId: _userId,
      conversationId: _conversationId,
      limit: 50,
    );

    Future.delayed(const Duration(milliseconds: 700), () {
      _historyRequestInFlight = false;
    });
  }

  Future<void> _loadUserFromController() async {
    if (_userController == null) return;
    await _userController!.getUserDetails();

    _userId = _userController!.getUserId.trim();
    _userName = _userController!.getUserName.trim().isEmpty
        ? 'User'
        : _userController!.getUserName.trim();
    _userImage = _userController!.getUserImage.trim();
  }

  void _handleSocketStateChanged() {
    if (!mounted || _socketProvider == null) return;
    if (!_socketProvider!.isConnected) {
      _conversationRequested = false;
      _joined = false;
      return;
    }

    if (_socketProvider!.conversationList.isNotEmpty) {
      _conversationListReceived = true;
    }
    final previousConversationId = _conversationId;

    _requestConversationList();

    final item =
        _resolveSupportConversationItem(_socketProvider!.conversationList);
    if (item != null) {
      final resolvedConversationId = _extractConversationId(item);
      final resolvedSupportUserId = _extractSupportUserId(item);
      final resolvedSupportName = _extractSupportName(item);
      final resolvedSupportImage = _extractSupportImage(item);

      if (_supportUserId.isEmpty && resolvedSupportUserId.isNotEmpty) {
        _supportUserId = resolvedSupportUserId;
        debugPrint('ChatSupport resolved supportUserId=$_supportUserId');
      }

      final hasCurrentInList = _conversationExistsInList(_conversationId);
      if (resolvedConversationId.isNotEmpty &&
          (_conversationId.isEmpty || !hasCurrentInList)) {
        _conversationId = resolvedConversationId;
        debugPrint('ChatSupport resolved conversationId=$_conversationId');
      }

      if (_supportName == 'Support' && resolvedSupportName.isNotEmpty) {
        _supportName = resolvedSupportName;
      }

      if (_supportImage.isEmpty && resolvedSupportImage.isNotEmpty) {
        _supportImage = resolvedSupportImage;
      }
    }

    if (previousConversationId != _conversationId) {
      _joined = false;
    }

    _joinConversationIfReady();

    if (_socketProvider!.isConnected &&
        _userId.isNotEmpty &&
        _supportUserId.isNotEmpty) {
      _socketProvider!.emitUserStatus(
        userId: _userId,
        checkUserId: _supportUserId,
      );
    }
  }

  Map<String, dynamic>? _resolveSupportConversationItem(
    List<Map<String, dynamic>> list,
  ) {
    if (list.isEmpty) return null;

    for (final item in list) {
      final otherId = _extractSupportUserId(item);
      if (_supportUserId.isNotEmpty && otherId == _supportUserId) {
        return item;
      }
    }
    return list.first;
  }

  bool _conversationExistsInList(String conversationId) {
    if (conversationId.trim().isEmpty || _socketProvider == null) return false;
    for (final item in _socketProvider!.conversationList) {
      if (_extractConversationId(item) == conversationId) return true;
    }
    return false;
  }

  String _extractConversationId(Map<String, dynamic> item) {
    return (item['conversation_id'] ?? item['_id'] ?? '').toString().trim();
  }

  String _extractSupportUserId(Map<String, dynamic> item) {
    final candidates = [
      item['receiver_id'],
      item['user_id'],
      item['target_user_id'],
      item['other_user_id'],
      item['admin_id'],
    ];

    for (final value in candidates) {
      if (value == null) continue;
      if (value is Map) {
        final id =
            (value['_id'] ?? value['user_id'] ?? value['id'] ?? '').toString();
        if (id.isNotEmpty && id != _userId) return id;
      } else {
        final id = value.toString().trim();
        if (id.isNotEmpty && id != _userId) return id;
      }
    }

    final users = item['users'];
    if (users is List) {
      for (final user in users) {
        if (user is Map) {
          final id =
              (user['_id'] ?? user['user_id'] ?? user['id'] ?? '').toString();
          if (id.isNotEmpty && id != _userId) return id;
        }
      }
    }

    return '';
  }

  String _extractSupportName(Map<String, dynamic> item) {
    final value = item['receiver_name'] ?? item['name'] ?? item['title'];
    if (value != null && value.toString().trim().isNotEmpty) {
      return value.toString().trim();
    }

    final receiverObj = item['receiver_id'];
    if (receiverObj is Map) {
      final name =
          (receiverObj['name'] ?? receiverObj['full_name'] ?? '').toString();
      if (name.trim().isNotEmpty) return name.trim();
    }

    return '';
  }

  String _extractSupportImage(Map<String, dynamic> item) {
    final value = item['receiver_image'] ?? item['image'];
    if (value != null && value.toString().trim().isNotEmpty) {
      return value.toString().trim();
    }

    final receiverObj = item['receiver_id'];
    if (receiverObj is Map) {
      final image = (receiverObj['profile_image'] ?? receiverObj['image'] ?? '')
          .toString();
      if (image.trim().isNotEmpty) return image.trim();
    }

    return '';
  }

  void _joinConversationIfReady() {
    if (!mounted || _socketProvider == null) return;
    if (_joined) return;
    if (_userId.isEmpty || _conversationId.isEmpty) return;
    if (!_socketProvider!.isConnected) return;

    debugPrint(
      'ChatSupport join+fetch => userId=$_userId conversationId=$_conversationId',
    );
    _socketProvider!.joinConversationChat(
      userId: _userId,
      conversationId: _conversationId,
      firstPageLimit: 50,
    );
    _joined = true;
  }

  bool _isMineMessage(Map<String, dynamic> message) {
    final senderId = _extractUserId(
      message['sender_id'] ?? message['senderId'] ?? message['user_id'],
    );
    return senderId.isNotEmpty && senderId == _userId;
  }

  String _extractUserId(dynamic raw) {
    if (raw == null) return '';
    if (raw is Map) {
      return (raw['_id'] ?? raw['user_id'] ?? raw['id'] ?? '')
          .toString()
          .trim();
    }
    return raw.toString().trim();
  }

  String _messageText(Map<String, dynamic> message) {
    return (message['message'] ?? '').toString();
  }

  List<String> _messageFiles(Map<String, dynamic> message) {
    final dynamic files = message['files'];
    if (files is! List) return const <String>[];
    return files
        .map((e) => e?.toString().trim() ?? '')
        .where((e) => e.isNotEmpty)
        .toList(growable: false);
  }

  String _fileUrl(String raw) {
    final value = raw.trim();
    if (value.isEmpty) return '';
    if (value.startsWith('http://') || value.startsWith('https://')) {
      return value;
    }
    final normalized = value.startsWith('/') ? value.substring(1) : value;
    return '${AppConfigProvider.imageUrl}$normalized';
  }

  bool _isVideoFile(String filePath) {
    final path = filePath.toLowerCase();
    return path.endsWith('.mp4') ||
        path.endsWith('.mov') ||
        path.endsWith('.avi') ||
        path.endsWith('.mkv') ||
        path.endsWith('.webm');
  }

  List<Map<String, String>> _previewMediaItems(
    Map<String, dynamic> message,
    List<String> files,
  ) {
    final explicitType = (message['type'] ?? '').toString().toLowerCase();
    return files.map((file) {
      final source = _fileUrl(file);
      final isVideo = explicitType == 'video' || _isVideoFile(file);
      return <String, String>{
        'type': isVideo ? 'video' : 'image',
        'url': source,
        'source': source,
        'thumbnail': source,
      };
    }).toList(growable: false);
  }

  Widget _buildMediaMessage(
    BuildContext context,
    Map<String, dynamic> message,
    bool mine,
    Size size,
  ) {
    final files = _messageFiles(message);
    if (files.isEmpty) return const SizedBox.shrink();

    final media = _previewMediaItems(message, files);
    final previewImages = media
        .map((item) => item['url'] ?? '')
        .where((e) => e.isNotEmpty)
        .toList();
    if (previewImages.isEmpty) return const SizedBox.shrink();

    final int total = media.length;
    final int visibleCount = total > 4 ? 4 : total;
    final List<Map<String, String>> visible = media.take(visibleCount).toList();
    final double boxSize = size.width * 0.62;

    Widget mediaTile(
      Map<String, String> item, {
      required int index,
      int extraCount = 0,
    }) {
      final bool isVideo = item['type'] == 'video';
      final String imageUrl = item['url'] ?? '';
      return GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ImagePreviewScreen(
                images: previewImages,
                media: media,
                initialIndex: index,
              ),
            ),
          );
        },
        child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          children: [
            Image.network(
              imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: Colors.black26,
                alignment: Alignment.center,
                child: const Icon(Icons.broken_image, color: Colors.white70),
              ),
            ),
            if (isVideo)
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.55),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.play_arrow,
                  color: Colors.white,
                  size: 26,
                ),
              ),
            if (extraCount > 0)
              Container(
                color: Colors.black.withOpacity(0.45),
                alignment: Alignment.center,
                child: Text(
                  '+$extraCount',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
          ],
        ),
      );
    }

    Widget gridBody;
    if (visibleCount == 1) {
      gridBody = mediaTile(visible[0], index: 0);
    } else if (visibleCount == 2) {
      gridBody = Row(
        children: [
          Expanded(child: mediaTile(visible[0], index: 0)),
          const SizedBox(width: 2),
          Expanded(child: mediaTile(visible[1], index: 1)),
        ],
      );
    } else if (visibleCount == 3) {
      gridBody = Column(
        children: [
          Expanded(
            child: mediaTile(visible[0], index: 0),
          ),
          const SizedBox(height: 2),
          Expanded(
            child: Row(
              children: [
                Expanded(child: mediaTile(visible[1], index: 1)),
                const SizedBox(width: 2),
                Expanded(child: mediaTile(visible[2], index: 2)),
              ],
            ),
          ),
        ],
      );
    } else {
      gridBody = Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(child: mediaTile(visible[0], index: 0)),
                const SizedBox(width: 2),
                Expanded(child: mediaTile(visible[1], index: 1)),
              ],
            ),
          ),
          const SizedBox(height: 2),
          Expanded(
            child: Row(
              children: [
                Expanded(child: mediaTile(visible[2], index: 2)),
                const SizedBox(width: 2),
                Expanded(
                  child: mediaTile(
                    visible[3],
                    index: 3,
                    extraCount: total > 4 ? (total - 4) : 0,
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return Container(
      width: boxSize,
      height: boxSize,
      decoration: BoxDecoration(
        color: mine ? AppColor.buttonColor : const Color(0xff262626),
        borderRadius: BorderRadius.circular(14),
      ),
      clipBehavior: Clip.hardEdge,
      child: gridBody,
    );
  }

  String _messageConversationId(Map<String, dynamic> message) {
    return (message['conversation_id'] ??
            message['conversationId'] ??
            message['conversation']?['_id'] ??
            '')
        .toString()
        .trim();
  }

  String _participantId(dynamic raw) {
    if (raw == null) return '';
    if (raw is Map) {
      return (raw['_id'] ?? raw['user_id'] ?? raw['id'] ?? '')
          .toString()
          .trim();
    }
    return raw.toString().trim();
  }

  bool _belongsToCurrentConversation(Map<String, dynamic> message) {
    final msgConversationId = _messageConversationId(message);
    if (_conversationId.isNotEmpty && msgConversationId.isNotEmpty) {
      return msgConversationId == _conversationId;
    }

    // Fallback for first-message flow (conversation_id can be empty/null).
    final sender = _participantId(message['sender_id'] ?? message['senderId']);
    final receiver =
        _participantId(message['receiver_id'] ?? message['receiverId']);
    final supportIdToUse = _supportUserId;

    if (sender.isEmpty || receiver.isEmpty || supportIdToUse.isEmpty) {
      return false;
    }
    return (sender == _userId && receiver == supportIdToUse) ||
        (sender == supportIdToUse && receiver == _userId);
  }

  bool _isNearBottom() {
    if (!_scrollController.hasClients) return true;
    final position = _scrollController.position;
    final distanceToBottom = position.maxScrollExtent - position.pixels;
    return distanceToBottom < 120;
  }

  void _maybeAutoScroll(int messageCount) {
    if (messageCount <= 0 || messageCount == _lastVisibleMessageCount) return;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (!_scrollController.hasClients) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _maybeAutoScroll(messageCount);
        });
        return;
      }

      final shouldAnimate = _didInitialScroll && _isNearBottom();
      final target = _scrollController.position.maxScrollExtent;
      if (!_didInitialScroll) {
        _scrollController.jumpTo(target);
        _didInitialScroll = true;
      } else if (shouldAnimate) {
        _scrollController.animateTo(
          target,
          duration: const Duration(milliseconds: 160),
          curve: Curves.easeOut,
        );
      }
      _lastVisibleMessageCount = messageCount;
    });
  }

  void _sendMessage() {
    final text = messageTextEditingController.text.trim();
    if (text.isEmpty) return;

    final socketProvider = Provider.of<SocketProvider>(context, listen: false);
    final receiverIdToUse = _supportUserId.trim();

    if (_userId.isEmpty || receiverIdToUse.isEmpty) {
      _requestConversationList();
      debugPrint(
        'ChatSupport not ready => userId=$_userId conversationId=$_conversationId supportUserId=$_supportUserId receiverIdToUse=$receiverIdToUse',
      );
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Support is loading. Please wait.')),
      );
      return;
    }

    debugPrint(
      'ChatSupport send => sender=$_userId receiver=$receiverIdToUse conversation=$_conversationId',
    );

    socketProvider.sendConversationMessage(
      senderId: _userId,
      senderName: _userName,
      senderImage: _userImage,
      receiverId: receiverIdToUse,
      receiverName: _supportName,
      receiverImage: _supportImage,
      conversationId: _conversationId,
      message: text,
      senderModel: 'User',
      receiverModel: 'Admin',
      files: const [],
    );
    if (_conversationId.isEmpty) {
      _scheduleConversationIdRefresh();
    }

    messageTextEditingController.clear();
    FocusScope.of(context).unfocus();
  }

  Future<void> _sendPickedMedia(List<Map<String, String>> picked) async {
    if (!mounted) return;
    if (_userId.isEmpty) {
      _requestConversationList();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Support is loading. Please wait.')),
      );
      return;
    }

    final imageOnlyPaths = picked
        .where((item) => (item['type'] ?? '').toLowerCase() == 'image')
        .map((item) => (item['file'] ?? '').trim())
        .where((p) => p.isNotEmpty)
        .toList(growable: false);

    if (imageOnlyPaths.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Support chat currently allows images only.')),
      );
      return;
    }

    final receiverIdToUse = _supportUserId.trim();
    if (receiverIdToUse.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Support is loading. Please wait.')),
      );
      return;
    }
    final socketProvider = Provider.of<SocketProvider>(context, listen: false);

    setState(() {
      _isUploadingMedia = true;
    });

    final success = await socketProvider.sendConversationMediaMessage(
      senderId: _userId,
      senderName: _userName,
      senderImage: _userImage,
      receiverId: receiverIdToUse,
      receiverName: _supportName,
      receiverImage: _supportImage,
      conversationId: _conversationId,
      localFilePaths: imageOnlyPaths,
      senderModel: 'User',
      receiverModel: 'Admin',
    );

    if (!mounted) return;
    setState(() {
      _isUploadingMedia = false;
    });

    if (!success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Unable to upload image. Please try again.')),
      );
      return;
    }
    if (_conversationId.isEmpty) {
      _scheduleConversationIdRefresh();
    }
  }

  void _openMediaPicker() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColor.primaryColor(context),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.photo_library_outlined),
                title: Text(AppLanguage.galleryText[language]),
                onTap: () async {
                  Navigator.pop(sheetContext);
                  try {
                    final List<XFile> pickedList =
                        await ImagePicker().pickMultiImage(
                      imageQuality: 100,
                      // limit: 10, // optional: cap at 10 images
                    );
                    if (!mounted) return;
                    if (pickedList.isEmpty) return;

                    final mediaList = pickedList
                        .map(
                          (picked) => <String, String>{
                            'type': 'image',
                            'file': picked.path,
                            'thumbnail': '',
                          },
                        )
                        .toList(growable: false);

                    _sendPickedMedia(mediaList);
                  } catch (e) {
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to pick images: $e')),
                    );
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera_outlined),
                title: Text(AppLanguage.cameraText[language]),
                onTap: () async {
                  Navigator.pop(sheetContext);
                  try {
                    final XFile? picked = await ImagePicker().pickImage(
                      source: ImageSource.camera,
                      imageQuality: 100,
                    );
                    if (!mounted) return;
                    if (picked == null) return;

                    _sendPickedMedia(<Map<String, String>>[
                      <String, String>{
                        'type': 'image',
                        'file': picked.path,
                        'thumbnail': '',
                      }
                    ]);
                  } catch (e) {
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to open camera: $e')),
                    );
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _socketProvider?.removeListener(_handleSocketStateChanged);

    if (_socketProvider != null &&
        _joined &&
        _userId.isNotEmpty &&
        _conversationId.isNotEmpty) {
      _socketProvider!.leaveConversationChat(
        userId: _userId,
        conversationId: _conversationId,
      );
    }

    messageTextEditingController.dispose();
    _scrollController.removeListener(_onChatScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: AppColor.primaryColor(context),
        body: Column(
          children: [
            SizedBox(height: size.height * 5 / 100),
            AppHeader(
              text: AppLanguage.chatSupportText[language],
              onPress: () => Navigator.pop(context),
            ),
            Expanded(
              child: _isBootstrapping
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: AppColor.buttonColor,
                      ),
                    )
                  : Consumer<SocketProvider>(
                      builder: (context, socketProvider, child) {
                        final messages = socketProvider.messages.where((m) {
                          return _belongsToCurrentConversation(m);
                        }).toList();
                        _maybeAutoScroll(messages.length);

                        if (_userId.isEmpty) {
                          return const Center(
                            child: Text(
                              'Unable to load user session.',
                              style: TextStyle(
                                color: Colors.white70,
                                fontFamily: AppFont.fontFamily,
                              ),
                            ),
                          );
                        }

                        if (messages.isEmpty) {
                          return const Center(
                            child: Text(
                              'No previous messages. Start chatting with support.',
                              style: TextStyle(
                                color: Colors.white70,
                                fontFamily: AppFont.fontFamily,
                              ),
                            ),
                          );
                        }

                        return ListView.builder(
                          controller: _scrollController,
                          padding: EdgeInsets.symmetric(
                            horizontal: size.width * 4 / 100,
                            vertical: size.height * 1 / 100,
                          ),
                          itemCount: messages.length +
                              (socketProvider.isLoadingMore ? 1 : 0),
                          itemBuilder: (context, index) {
                            if (socketProvider.isLoadingMore && index == 0) {
                              return const Padding(
                                padding: EdgeInsets.symmetric(vertical: 8),
                                child: Center(
                                  child: Text(
                                    'Loading...',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontFamily: AppFont.fontFamily,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              );
                            }

                            final actualIndex = socketProvider.isLoadingMore
                                ? index - 1
                                : index;
                            if (actualIndex < 0 ||
                                actualIndex >= messages.length) {
                              return const SizedBox.shrink();
                            }

                            final message = messages[actualIndex];
                            final mine = _isMineMessage(message);
                            final text = _messageText(message);
                            final files = _messageFiles(message);
                            final hasMedia = files.isNotEmpty;

                            return Align(
                              alignment: mine
                                  ? Alignment.centerRight
                                  : Alignment.centerLeft,
                              child: Container(
                                margin: EdgeInsets.only(
                                  bottom: size.height * 1.2 / 100,
                                ),
                                child: Column(
                                  crossAxisAlignment: mine
                                      ? CrossAxisAlignment.end
                                      : CrossAxisAlignment.start,
                                  children: [
                                    if (hasMedia)
                                      _buildMediaMessage(
                                        context,
                                        message,
                                        mine,
                                        size,
                                      ),
                                    if (text.trim().isNotEmpty)
                                      Container(
                                        margin: EdgeInsets.only(
                                          top: hasMedia ? 8 : 0,
                                        ),
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 14,
                                          vertical: 10,
                                        ),
                                        decoration: BoxDecoration(
                                          color: mine
                                              ? AppColor.buttonColor
                                              : const Color(0xff262626),
                                          borderRadius:
                                              BorderRadius.circular(14),
                                        ),
                                        child: Text(
                                          text,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 14,
                                            fontFamily: AppFont.fontFamily,
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
            ),
            SizedBox(
              width: size.width * 90 / 100,
              child: TextFormField(
                cursorColor: AppColor.secondryColor(context),
                style: TextStyle(
                  height: 1,
                  color: AppColor.secondryColor(context),
                ),
                textAlignVertical: TextAlignVertical.center,
                keyboardType: TextInputType.text,
                maxLength: AppConstant.describeLength,
                controller: messageTextEditingController,
                onFieldSubmitted: (_) => _sendMessage(),
                decoration: InputDecoration(
                  isDense: true,
                  suffixIconConstraints: BoxConstraints(
                    maxWidth: size.width * 30 / 100,
                  ),
                  suffixIcon: Padding(
                    padding: const EdgeInsets.only(left: 4.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                          onTap: _isUploadingMedia ? null : _openMediaPicker,
                          child: _isUploadingMedia
                              ? SizedBox(
                                  width: size.width * 7 / 100,
                                  height: size.width * 7 / 100,
                                  child: const CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: AppColor.buttonColor,
                                  ),
                                )
                              : Image.asset(
                                  AppImage.plusIcon,
                                  height: size.width * 7 / 100,
                                  width: size.width * 7 / 100,
                                  color: AppColor.secondryColor(context),
                                ),
                        ),
                        SizedBox(width: size.width * 3 / 100),
                        GestureDetector(
                          onTap: _sendMessage,
                          child: Image.asset(
                            AppImage.shareImg,
                            height: size.width * 7 / 100,
                            width: size.width * 7 / 100,
                            color: AppColor.secondryColor(context),
                          ),
                        ),
                        SizedBox(width: size.width * 3 / 100),
                      ],
                    ),
                  ),
                  border: const OutlineInputBorder(
                    borderSide: BorderSide(color: AppColor.washpressColor),
                    borderRadius: BorderRadius.all(Radius.circular(40)),
                  ),
                  enabledBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: AppColor.washpressColor),
                    borderRadius: BorderRadius.all(Radius.circular(40)),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: AppColor.washpressColor),
                    borderRadius: BorderRadius.all(Radius.circular(40)),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 16, horizontal: 15),
                  fillColor: AppColor.washpressColor,
                  filled: true,
                  counterText: '',
                  hintText: AppLanguage.messageText[language],
                  hintStyle: TextStyle(
                    color: AppColor.chatSupportcolor(context),
                    fontFamily: AppFont.fontFamily,
                    fontWeight: FontWeight.w400,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            SizedBox(height: size.height * 2 / 100),
          ],
        ),
      ),
    );
  }
}
