import 'socket_provider.dart';

/// Separate socket state for user-to-user chat screens.
class UserChatSocketProvider extends SocketProvider {
  UserChatSocketProvider() : super(enableLifecycleReconnect: false);
}
